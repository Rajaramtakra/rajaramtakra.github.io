# Page Builder

A Claude Code agent pipeline that creates new pages inside an **existing local WordPress project**, from a Figma design, an AI-generated HTML reference, or plain screenshots of the page you want — by first discovering the site's real architecture and reusing it, instead of introducing a new pattern.

Primary rule: *the existing WordPress project is the source of truth for **how** the page is implemented; the reference — Figma, HTML, or screenshots — is the source of truth for **what it looks like**.*

**The shape of it:** one installation serves many projects, each with its own persistent site intelligence — and the discovery work that a model would otherwise redo on every single run happens deterministically in Node, once per project.

### Start here

| Document | What it covers |
| :-- | :-- |
| **[docs/walkthrough/](docs/walkthrough/index.html)** | **An interactive, eight-step walk-through of one whole run.** Step 1 is a self-check: answer three or four questions and it tells you whether this project runs straight through, needs a step from you first, or has to wait for an install to build into. Plain HTML — open it in a browser, no server needed. |
| This file | How it works, and why each decision was made the way it was |
| [configuration.md](configuration.md) | How the project is wired — what the Claude Code harness loads and from which path, the deterministic scripts and file contracts around it, and what is deliberately not configured |

If you just want to build a page, read the walk-through and skip the rest of this file. It exists to explain the reasoning, and most of it is reasoning you do not need in order to use the tool.

---

## The idea in one page

The obvious way to build this is a single-project workflow: every run, re-inventory the whole install into one flat handoff, catalogue every reusable component on the site, and only then look for a similar page. Nothing survives the session, so page two costs the same as page one.

This splits the work by what actually needs a model instead:

| Work | Who does it | Cost per run |
| :-- | :-- | :-- |
| Resolve the WordPress root, stack, DB reachability | launcher (Node) | 0 tokens |
| Extract all site content — pages, CPTs, menus, taxonomies, builder usage | launcher (Node), from the DB or a WXR export | 0 tokens |
| Enumerate themes, plugins + active flags, templates, ACF groups, CPT registrations, CSS/JS, design tokens | launcher (Node) | 0 tokens |
| List every candidate reusable component, with usage links | launcher (Node) | 0 tokens |
| **Decide** which builder, which page is closest, which component serves which section | agents | paid once |
| **Describe** what a component renders — for the handful the page needs | agents | paid once, then cached |
| Build the page, render it, compare it against the design, fix it | agents | paid per page |

Discover once, cache, reuse. The first page for a project pays for the judgment; every page after it reads the cache.

### Measured on a real 54-page Astra/Gutenberg site

| | If a model does it all | As built |
| :-- | --: | --: |
| Handoff every child agent read, every dispatch | 86 KB — **~24,500 tokens** | manifest + architecture + content index: 26 KB — **~7,400 tokens** |
| Finding the closest existing page | full component catalog first | 4-page `kind` slice — **~640 tokens** |
| Components described per run | all 50 | only the shortlist (typically 5–15), then cached |
| Theme files enumerated by a model | 621 | 0 |
| PHP files grepped for CPT registrations by a model | ~2,000 | 0 |
| Second page on the same project | full rediscovery | cache load |

And on a WXR project: a 36 MB export (**~10.5M tokens if a model ever read it**) becomes 111 KB of indexes — 334× smaller — parsed exactly once, in the launcher.

---

## The four agents

An orchestrator plus three workers, each pinned to the model tier its phase actually needs.

| Agent | File | Model | Owns |
| :-- | :-- | :-- | :-- |
| **page-builder** | [.claude/agents/page-builder.md](.claude/agents/page-builder.md) | inherit | Orchestration · architecture reasoning · closest-page analysis · reuse decisions |
| **wp-scout** | [.claude/agents/wp-scout.md](.claude/agents/wp-scout.md) | Haiku / Sonnet | `RECON` — confirm and gap-fill · `TARGETED` — inspect only what this page needs |
| **wp-implementer** | [.claude/agents/wp-implementer.md](.claude/agents/wp-implementer.md) | Sonnet | Analyze the reference, build the page |
| **wp-visual-qa** | [.claude/agents/wp-visual-qa.md](.claude/agents/wp-visual-qa.md) | Opus, effort `high` | Validate, compare, root-cause, fix |

`wp-scout` runs in two modes. `RECON` confirms the launcher's picture and closes its gaps, on Haiku. `TARGETED` describes what specific code renders, which needs real reading comprehension — so the orchestrator dispatches it with a per-invocation `model: sonnet` override. (`INVENTORY` and `CATALOG` are still accepted as aliases for the two modes.)

**You only ever invoke `page-builder`.** It spawns the other three itself.

### Why the models are split this way

Routing is by **phase**, not by a guess at "task difficulty." Phase is known; difficulty is inferred, and a bad inference fails silently.

- **Haiku** for recon — confirming a fact the launcher already established has no judgment in it.
- **The orchestrator's own model** for the reasoning, because *which builder the comparable pages actually use* and *which page is closest* are the calls everything downstream depends on.
- **Sonnet** for describing components and for the build.
- **Opus** for QA, because comparing a render against a design and correctly diagnosing *why* it differs is the hardest reasoning here, and it benefits from fresh eyes that didn't write the code.

### The escalation ladder

Opus does **not** review every line Sonnet writes. That would roughly double cost on the most token-heavy phase, and a reviewer arriving without the implementer's reasoning tends to produce confident rewrites that undo correct decisions — turning a deliberate reuse of an existing component into a pixel-perfect one-off, which is a direct violation of the primary rule.

Opus is the **comparator**, and becomes the **fixer** only after Sonnet demonstrably fails:

```
Round 1:  wp-visual-qa (REPORT-ONLY)  ->  PASS? done
          defects  ->  wp-implementer fixes
Round 2:  wp-visual-qa (REPORT-ONLY)  ->  PASS? done
          defects  ->  wp-implementer fixes
Round 3:  wp-visual-qa (REPORT-ONLY)  ->  PASS? done
          still failing  ->  wp-visual-qa (FIX) — Opus takes over
Round 4:  wp-visual-qa (REPORT-ONLY)  ->  verify
          still failing  ->  stop, report defects honestly
```

On a clean build Opus never touches the code. **That is deliberate.** Token optimization comes from not re-reading the project, never from looking at the page less carefully.

---

## The workspace

Every project gets an isolated directory. Nothing is ever written inside the client's WordPress install.

```
.claude/tmp/
├── projects.json                      registry index (rebuildable)
├── staging/                            uploaded WXR or screenshots awaiting a project
├── legacy/migration.json               ledger of imported legacy files
│
├── acme-website/
│   ├── project.json                    canonical project record
│   ├── site-intelligence/
│   │   ├── manifest.md                 what is here, and what each file answers  <- agents read this first
│   │   ├── architecture.json           host OS, theme, plugins, ACF, CPTs, styling, DB availability
│   │   ├── architecture.md             the same as prose + an agent-authored section
│   │   ├── content-index.json          counts, builder usage per post type, taxonomies
│   │   ├── pages-index.json            one row per page + a structure signature
│   │   ├── cpt-index.json              custom post types and their items
│   │   ├── menus-index.json            nav menus, with linked objects resolved
│   │   ├── component-index.json        every candidate component; `renders` filled lazily
│   │   ├── template-index.json         templates, page templates, theme file list
│   │   ├── asset-index.json            CSS/JS inventory, enqueues, theme.json tokens
│   │   ├── scan-meta.json              fingerprints and staleness state
│   │   └── source/wordpress-export.xml the original WXR, parsed once, never read by an agent
│   ├── pages/
│   │   ├── page-history.json           what has been built for this project
│   │   └── <page-slug>/                reference sections, reuse table, QA rounds
│   │       ├── progress.json           which of the 14 phases the run is in
│   │       └── reference/              the uploaded screenshots, for a screenshot reference
│   └── logs/
│
├── another-client/                     completely isolated
└── third-project/
```

Two projects never share a conclusion. That isolation is the point — a cached judgment about one client's site leaking into another's is the specific error this structure prevents.

### The manifest is the entry point

`manifest.md` is ~60 lines: what was scanned, when, from which content source, and a table saying which of the ten files answers which question. An agent reads that, then opens two or three files — not 300 KB of JSON. It is the difference between "read the intelligence" meaning something cheap and meaning something expensive.

### Staleness, not re-scanning

`scan-meta.json` carries lightweight fingerprints — a hash of the theme tree's shape and mtimes, the plugin directory, and the content. Selecting a project recomputes two of them and reports *why* the cache looks stale ("the active theme has changed", "plugins have been added"). 

**Start Building never re-scans.** Refreshing is an explicit button, because a full re-index on every page defeats the purpose of caching one.

---

## WordPress content: automatic first, XML only as a fallback

You are never asked for an XML export when the launcher can read the database itself.

```
Project Path
      ↓
Resolve the WordPress root (by markers, never by directory name)
      ↓
Read wp-config.php · identify the local stack
      ↓
Can the database be reached?
 ┌────┴────┐
YES        NO
 ↓          ↓
extract    ask for a WXR/XML export
 ↓          ↓
 └─── one normalized content model ───┘
                ↓
     content-index · pages-index · cpt-index · menus-index
```

Downstream agents cannot tell which path was taken, and do not need to.

### How the database is reached

Three transports, tried in order:

1. **The stack's own `mysql` client** — MAMP's, LocalWP's, XAMPP's, WAMP's, Laragon's, Homebrew's, a standalone MySQL/MariaDB install, or whatever is on `PATH`. Connection targets come from `wp-config.php` first, then the sockets and ports the detected stack is known to use — Unix sockets on macOS and Linux, TCP ports on Windows, which has none. This is the most reliable path locally, and usually answers in under 100 ms.
2. **`wp db query`** — when WP-CLI's own PHP can connect. Often it cannot: PHP resolves `localhost` to *its* default socket, which is not MAMP's when Herd or Valet is first on `PATH`. That failure is exactly why transport 1 comes first. SQL goes in over **stdin**, not as an argument, so a query is never reshaped by the shell — on Windows `wp` is a `.cmd`/`.bat` shim that has to be launched through `cmd.exe`, and `cmd.exe` expands `%…%` even inside quotes.
3. **`docker compose exec`** — best effort for containerised stacks, reading the DB service name out of the compose file.

No client found is reported as its own failure, distinct from a client that ran and could not connect, because the fix is different. If your stack keeps `mysql` somewhere none of the above looks — a second drive, a portable install — point at it directly:

```bash
PB_MYSQL_BIN=/path/to/mysql node launcher/start.js     # macOS / Linux
set PB_MYSQL_BIN=D:\stack\mysql\bin\mysql.exe && node launcher\start.js   # Windows
```

When none of them work, the launcher says *why* in plain language — "the local MySQL server appears to be stopped", "the credentials in wp-config.php were rejected", "wp-config.php computes its credentials at runtime" — and offers the XML fallback.

### Build progress

The pipeline runs in Claude Code, not in the launcher, so progress cannot be *measured* here — it has to be **reported**. Leave the launcher tab open and it shows one segment per phase, fourteen of them:

```
Levels of Care   BUILDING                                          86%
▰▰▰▰▰▰▰▰▰▰▰▰▱▱
Phase 13 of 14 — Visual comparison (wp-visual-qa)
5 QA rounds · comparing the stat band at tablet · last change 19s ago · reported by the pipeline
```

Segments rather than a smooth bar, because the phase count is the useful number: five of those fourteen are one dispatched build, and the QA loop can run many rounds inside phases 12–14. The current phase is highlighted, not filled — the bar never claims a phase finished while it is still running.

Two sources, in this order:

1. **`progress.json`**, written by the orchestrator as it crosses each phase boundary. Authoritative.
2. **The artifacts the phases leave behind** — `reuse-decisions.md`, `implementation.md`, `qa-round-N.md`. Used when there is no report, and labelled *inferred from files on disk* so you know which you are looking at.

The fallback exists because an agent can skip an instruction, and a bar that vanishes when that happens is worse than one that says "at least phase 11, from the files". It is deliberately conservative: an artifact proves only its own phase finished, so a finished page with no report reads as 79%, not 100%.

Precedence between the two is decided by **timestamp, not phase number**. Artifacts newer than the report mean the run moved on without updating it, and they win. Artifacts *older* than the report belong to a previous attempt — rebuilding a page starts with attempt one's `implementation.md` and QA rounds still on disk, and comparing numbers alone would report phase 12 while attempt two is honestly at phase 3.

This also fixes something that was quietly wrong: `page-history.json` recorded `status: "started"` at handoff and **nothing ever advanced it**, so a page that finished with five QA rounds read as "started" for ever. A run the pipeline reports as finished now folds back into the history, so the two views cannot disagree.

### Where is the database?

Detection is right most of the time and silent when it is. When it is not, **Where is the database?** in the launcher makes it visible and overridable instead of leaving the XML export as the only way out.

**Detect servers** sweeps every candidate socket and port and reports what is actually behind each one:

```
mamp · 2 MySQL servers of 4 checked · wp-config wants localhost/demo_db · 2 client(s) available

  ○ /Applications/MAMP/tmp/mysql/mysql.sock   MySQL 5.7.39         MYSQL
  ○ 127.0.0.1:8889                            MySQL 5.7.39         MYSQL
    127.0.0.1:3306                            connection refused   NO SERVER
    127.0.0.1:3307                            connection refused   NO SERVER
```

That sweep runs **without a username, a password, or a client binary**. A MySQL server sends its handshake the moment a connection opens — protocol version, then its version string — so reading those first bytes identifies the server and its version outright. Anything else answering on the port fails to parse and is reported as `in use` rather than mistaken for a database.

Pick a row, or set **host / port / socket / database / mysql client** by hand; blank fields still fall to detection. **Test connection** re-probes without committing, and what you keep is saved with the project so **Refresh** reconnects the same way. **Clear** returns it to auto-detection.

Two deliberate constraints:

- **No username or password field.** Credentials stay in `wp-config.php`, which keeps the guarantee above — nothing the launcher writes contains one — true for the override record as well. When the credentials themselves are wrong, `wp-config.php` is the thing to fix.
- **An explicit connection is used exclusively**, never as the first of several guesses. Succeeding through a transport that ignored what you asked for would report a connection you did not request and leave your setting untested. So when a named target fails, the launcher probes *it* and says which of the three cases applies — nothing is listening, something is listening but is not MySQL, or the server answered and the credentials or database name are the problem.

**Credentials never reach a process argument list.** The CLI transport writes a `0600` `--defaults-extra-file` and deletes it — on Windows, where that mode is a no-op, the file lands in the per-user `%LOCALAPPDATA%\Temp` whose default ACL restricts it to that user, and it exists only for the length of one query. The docker transport pipes the whole invocation over stdin. Nothing written to disk contains a password: `wp_options` is read through an **allowlist** (that table is where plugins park API keys and SMTP passwords), and the intelligence files record only whether the database was reachable and via what host or socket.

### What gets extracted

Targeted projections, never a dump. `post_content` and `_elementor_data` are read only to derive a compact **structure signature** — the block or widget names a page renders, its section count, its word count — and the raw text is discarded. A 200-page Elementor site produces a ~200 KB index from tens of megabytes of builder JSON.

### The WXR fallback

Export from **WordPress Admin → Tools → Export → All content**, then drop the file into the launcher. It is validated by actually parsing it, so the failures people really hit get named rather than accepted:

- a sitemap or a random XML file → *"not a WordPress export — no `<rss>`/`<channel>` element"*
- a plain RSS feed → *"the `wp:` namespace is missing; use Tools → Export → All content"*
- a truncated export → parses as far as it goes, and reports honestly how many content items it actually found
- an `<item>` whose closing tag never arrives → skipped and **named as such** ("the export looks truncated or corrupt"), the parser resynchronises on the next item so the ones after it are still recovered, and memory stays bounded at 8 MB per item

It is parsed **once**, at upload, into the same normalized model the database produces. The XML is kept under `site-intelligence/source/` for provenance, and every agent is explicitly told never to open it.

**XML is not the source of truth for code.** It carries content — pages, posts, CPT data, menus, metadata, builder signatures. Templates, PHP, CSS, JS, ACF definitions, and builder implementation come from source-code inspection. A WXR also cannot tell you the active theme or which plugins are active, so the launcher says so and `wp-scout` is told to confirm the theme it inferred.

---

## Closest page first, cataloging second

This ordering change is where most of the remaining savings come from.

```
obvious:  catalog every component on the site  ->  then look for a similar page
here:     find the closest existing page       ->  then inspect only what it uses
```

Every row in `pages-index.json` carries a `kind` (service, location, about, contact, pricing, blog, …), its `template`, its `builder`, and a `signature`:

```json
{
  "id": 4589, "title": "Alimony Legal Services for Men Only",
  "slug": "alimony", "kind": "service", "template": "default", "builder": "Gutenberg",
  "signature": {
    "elements": ["uagb/container", "uagb/info-box", "uagb/advanced-heading", "columns"],
    "sectionCount": 39, "wordCount": 827
  }
}
```

That is enough to rank candidates without opening a single file. The orchestrator filters by `kind`, narrows by builder/template/signature, picks two to four pages, and only then sends `wp-scout` to describe the 5–15 components those pages actually use.

`component-index.json` is seeded by the launcher with every candidate's path plus free usage links — `includedBy` from `get_template_part()` / `@include` / `{% include %}` call sites, and `usedOnPages` by matching block and widget names against page signatures. `renders` stays `null` until an agent describes it, and those descriptions **persist**, so the next page starts with them already paid for.

### What is never opened

```
node_modules/  vendor/  .git/  wp-content/uploads/  wp-content/cache/
wp-content/upgrade/  backups/  logs/  *.log  *.map  *.min.js  *.min.css
```

`wp-content/plugins/` is enumerated (name, version, active flag) and grepped shallowly for CPT/taxonomy registrations, but never deeply catalogued. A plugin's source is opened only when a specific page demonstrably depends on it.

---

## What is deliberately not Claude's job

The pipeline pays per token, so anything mechanical belongs in a script. Two live in [tools/](tools/), both dependency-free Node that behaves identically on macOS, Windows and Linux, and both are named in the generated prompt with their absolute path (Claude Code's working directory is the WordPress project, not this folder).

### `verify-page.js` — Phase 12, without an agent

Phase 12 asks only factual questions, and a script answers them exactly:

```bash
node tools/verify-page.js --project acme --page contact-us --baseline locations
```

```
  FAIL  Page loads
         http://localhost:8888/smartsites/acme/contact-us/ -> 500
  FAIL  WordPress error page
         The response is WordPress's critical-error page, not the page template.
  ok    Assets load
         38 local asset(s) all load, 6 external not checked.
```

Page status · WordPress's own critical-error page (which can arrive with a 200) · PHP fatals, warnings, notices and deprecations in the rendered output · **every** local script, stylesheet, image and `srcset` variant · the homepage and each `--baseline` page · `wp-content/debug.log`, including whether its contents are recent enough to belong to this build. Exit 0 means everything passed, and only failures are printed.

A rendered page on this install is **217 KB — about 55,000 tokens** to read into context, per page, per attempt, and reading it can *still* miss the one stylesheet that 404s. The script costs none of that and cannot miss one.

**It is deliberately narrow, and the agent instructions say so.** It does not check that the page resolved to the correct template, that ACF fields render real values instead of empty strings, or that the console is free of JavaScript errors — a 200 proves something rendered, not that the right thing did. Those stay with the agent, as does all of Phase 13.

### `query-index.js` — the indexes, without the redundancy

`pages-index.json` is 41 KB on a 54-page site, and Phase 3 reads it whole to pick a few comparable pages. The indexes are written for completeness — absolute paths on every entry, full SEO titles, every URL — which is right on disk and wasteful in a context window.

```bash
node tools/query-index.js pages      --project acme
node tools/query-index.js pages      --project acme --like our-services
node tools/query-index.js components --project acme --grep hero
```

| View | On disk | Compact | Saved |
| :-- | --: | --: | --: |
| `pages-index.json` (54 pages) | ~10,600 tok | ~2,000 tok | **81%** |
| `component-index.json` (50 components) | ~5,900 tok | ~1,000 tok | **83%** |

This is **compression, not delegation** — the distinction that keeps it from costing accuracy. Every page and every component is still listed, so the judgment is unchanged and nothing the agent could previously have chosen has become invisible. `--like` adds a printed, arguable similarity score that reorders and never truncates; `--limit` hides rows and says how many, which is fine for reporting and wrong for a decision, so the agent instructions forbid it while choosing.

### What stays with Claude, and why

Not everything mechanical-looking is safe to mechanise:

| Work | Where it belongs |
| :-- | :-- |
| Asset 404s, PHP errors, page status, regressions | **script** — facts, and a script is *more* reliable than reading 217 KB |
| Ranking and filtering the indexes | **script** — arithmetic over fields the launcher already computed |
| Which existing component to reuse, extend, or replace | **Claude** — judgment, and the whole point of the pipeline |
| Section-by-section visual comparison | **Claude** — this is the phase the accuracy lives in |
| Root-causing why a section differs | **Claude** — a diff can say *where*, never *why* |
| Writing the page | **Claude** |

The next safe candidates, not yet built: outlining a custom-HTML reference into a section list rather than reading the whole file, and asserting template/ACF resolution through WP-CLI. Pixel-diffing screenshots is deliberately **not** on that list — it could say which regions differ, but it invites trusting a number over looking at the page, and that trade is the one thing this pipeline will not make.

## Install

Three things, once per machine. None of them is per project, and none is per run.

### 1 — Node 18 or newer

```bash
node --version
```

That is the launcher's only prerequisite, on all three platforms. No `npm install`, no native modules, nothing that shells out to a Unix tool.

### 2 — Put the four agents where Claude Code looks

Claude Code discovers subagents from `.claude/agents/` **relative to its working directory**, and from `~/.claude/agents/` for every project. This folder ships the four definitions in its own `.claude/agents/`, so out of the box they are found only when Claude Code starts here. Two ways to set that up, and the choice decides where you open Claude Code:

| Install | Open Claude Code in | Consequence |
| :-- | :-- | :-- |
| Copy the four files into `~/.claude/agents/` | the WordPress project | The agents are available in every project, and the working directory *is* the install — which is what the generated prompt assumes. Re-copy after editing an agent. |
| Leave them in `.claude/agents/` here | the Page Builder folder | Nothing to install, and an edit to an agent takes effect immediately — but the WordPress install is then outside the working directory, so Claude Code asks for access to it before it can read or write the site. |

Either way the generated prompt names the intelligence directory and both helper scripts **by absolute path**, so they resolve from whichever directory you chose.

### 3 — Allowlist the two helper scripts — automatic

`verify-page.js` and `query-index.js` run on essentially every build, and without an allowlist entry each call stops the pipeline for an approval prompt. `.claude/settings.json` allows exactly those two, quoted and unquoted:

```
Bash(node "<install>/tools/query-index.js" *)
Bash(node "<install>/tools/verify-page.js" *)
```

**Those entries name a specific install path.** Permission rules match by prefix and the prompt invokes the scripts absolutely, so there is no portable form. **You do not have to maintain them by hand:** every launcher start runs [`launcher/lib/preflight.js`](launcher/lib/preflight.js), which rewrites those four rules to match wherever this folder actually is. Move the folder, clone it onto another machine, rename a parent directory — the next start repoints them and says so. Rules you added yourself are preserved, and a correct install is rewritten by nothing and prints nothing.

That matters because the failure mode is otherwise a long way from its cause: stale paths break nothing at startup, and surface much later as approval prompts interrupting a build in progress.

Deliberately **not** `Bash(node *)`, which would allow arbitrary code execution through the interpreter.

`.claude/settings.local.json` is personal and unshared, so anything every run needs belongs in `.claude/settings.json` instead.

### Optional — the Figma connector

Only if you intend to hand it Figma links rather than HTML or screenshots. See *Reading the design reference* below: without the connector authorized, a Figma link is just a URL the agent cannot open, and the pipeline will tell you so rather than guessing. Screenshots and HTML need nothing installed.

---

## The launcher

A small local web UI. Zero dependencies, binds `127.0.0.1` only, makes no outbound requests, and writes only inside `.claude/tmp/`.

Double-click the starter for your platform, in the Page Builder folder:

| Platform | File |
| :-- | :-- |
| macOS | **`Start Page Builder.command`** |
| Windows | **`Start Page Builder.cmd`** |

Or from any terminal:

```bash
node launcher/start.js           # start + open browser
node launcher/server.js          # server only
```

Safe to run repeatedly — if the server is already up it just opens the page. It keeps running in the background after you close the terminal, and the script prints the command to stop it (`kill <pid>`, or `taskkill /PID <pid> /F`). If port 4599 is taken by something else, it says so and shows how to use another port. Requires **Node 18+** and nothing else — no npm install, no native modules.

**It restarts itself when the code changes.** Reusing a running server is what makes the starter cheap, but a server started before an edit keeps serving its old routes forever — and because `public/index.html` is read from disk on every request, the *page* updates while the *server* does not. The failure that produces is genuinely confusing: a button that exists in the UI gets a `404 Not found` from a process that has never heard of it.

So `/api/health` reports a `build` id — a hash of `server.js` and `lib/*.js` by size and mtime, taken at startup, so it describes the code that process actually loaded. The starter compares it against the same hash of what is on disk:

| Port answers | Starter does |
| :-- | :-- |
| our launcher, build matches | reuses it, opens the browser |
| our launcher, build differs (or reports none) | **stops it and starts a new one** |
| something else | refuses to touch it, suggests another port |

Stopping is `process.kill(pid)` — no `kill`/`taskkill` branch and no shell. On POSIX SIGTERM lets the server close its listener cleanly; on Windows it terminates the process outright, since signals do not exist there. Both release the port, which is the only thing the starter waits on. A process that will not stop is reported with the command to stop it by hand, rather than being left half-killed.

### Platform support

macOS, Windows and Linux, with **Node 18+** the only prerequisite on all three. Nothing in the launcher shells out to a Unix tool: port detection asks `/api/health` rather than running `lsof`, directory walks use `fs`, and the two starter files are thin wrappers whose only job is locating Node.

What differs per platform is only what genuinely differs:

| | macOS / Linux | Windows |
| :-- | :-- | :-- |
| Starter | `Start Page Builder.command` | `Start Page Builder.cmd` |
| Stacks detected | MAMP, XAMPP/LAMPP, LocalWP, Herd, Valet, DDEV, Lando, wp-env, Docker | MAMP, XAMPP, WAMP, Laragon, LocalWP, DDEV, Lando, wp-env, Docker |
| DB connection | Unix sockets, then TCP | TCP only — Windows has no Unix sockets |
| WP-CLI entry point | `wp` | `wp.bat`, `wp.cmd`, then `wp`, launched via `cmd.exe` |
| Browser open | `open` / `xdg-open` | `start` |

Paths are used in whatever form the platform gives them, and never rewritten. The one exception is **component and template names**, which are normalized to forward slashes before being stored — those names are matched against the strings inside `get_template_part()`, `@include` and `{% include %}`, which are `/`-separated in every WordPress codebase regardless of the OS that wrote them. Storing a Windows `template-parts\hero.php` would make every include lookup miss silently, and an empty `includedBy` reads as dead code.

Asking `/api/health` who holds the port is how it tells "already running" apart from "someone else has this port". All the real logic lives in [launcher/start.js](launcher/start.js), so every platform runs identical code.

### Moving the install to another Mac

Double-clicking `Start Page Builder.command` on a Mac that did not create it usually fails with *"Apple could not verify … is free of malware"* and offers only **Move to Trash** or **Done**. Nothing is wrong with the file. macOS attaches `com.apple.quarantine` to anything that arrives by browser download, AirDrop or a sync client, and Gatekeeper will not run a quarantined script from Finder unless it carries a paid Developer ID signature. The flag belongs to the copy, not to the folder's contents, which is why the same files launch on the machine they came from.

Clearing it takes one line, once per machine — the trailing space is there so the folder can be dragged from Finder onto the Terminal window instead of typing its path:

```bash
xattr -dr com.apple.quarantine "/path/to/Page Builder"
```

The alternative without Terminal is *System Settings → Privacy & Security → Open Anyway*, which has to be repeated per blocked file rather than covering the folder at once. Right-click → Open worked until macOS 15 Sequoia, which removed that shortcut.

Because a quarantined script never runs, it cannot clear its own flag — the first launch on a new Mac has to come from one of those two routes. After that the starter keeps the problem from returning: every run strips the flag from itself, `launcher/` and `tools/`, and restores its own executable bit, so a folder that a sync client re-flags heals on the next launch rather than failing again. `.claude/tmp/` and any WordPress install below it are deliberately left alone.

Quarantine is attached by the transfer rather than by the file, so the choice of transfer decides whether the first-run step is needed at all:

| | Transfer |
| :-- | :-- |
| No flag | `git clone`, `scp`, `rsync`, USB or network-share copy |
| Flag attached | browser download, AirDrop, Google Drive, Dropbox, iCloud Drive, Slack, email attachment |

For an install that moves between machines regularly, a git repository is the fix: files that git writes are never quarantined, so a clone needs no first-run step. [READ ME FIRST (macOS).txt](READ%20ME%20FIRST%20%28macOS%29.txt) carries the same instructions in plain text, since a `.txt` still opens in Finder when the script beside it will not.

Windows has no equivalent block for `.cmd` files run from a local folder, though SmartScreen may warn once on a `.cmd` extracted from a downloaded zip; Linux only needs `chmod +x` if the transfer dropped the bit.

### New Project

```
Project        ● New Project   ○ Existing Project
Project Name   [ Acme Website ]
Project Path   [ /Users/.../acme ]
```

Leaving the path field triggers a live inspection: the WordPress root is resolved, the stack identified, and the database probed. The **WordPress Content** choice then defaults itself — `Auto-detect` when the database answered, `Upload WXR/XML` when it did not — so the common case needs no decision from you.

```
WordPress Content  ● Auto-detect  ○ Upload WXR/XML  ○ Skip

Page Name          [ Contact Us ]
Reference          ● Figma  ○ Custom HTML  ○ Screenshot
Figma Link         [ https://www.figma.com/design/… ]
Additional Notes — optional
                   [ Reuse the CTA block from /services.        ]
                   [ The hero video is a placeholder.           ]

[ Add another page ]
[ Start Building ]
```

Choosing **Screenshot** replaces that page's reference field with an upload and one optional URL:

```
Reference          ○ Figma  ○ Custom HTML  ● Screenshot

Screenshots        [ Choose Files ]   3 ready
                   01 hero-desktop.png   DESKTOP  1440×4200 · 812 KB
                   02 tablet.png         TABLET    834×3900 · 402 KB
                   03 mobile.png         MOBILE    390×3800 · 268 KB

Existing live reference URL — optional
                   [ https://staging.acme.com/contact ]
```

Each image is identified from its own bytes, not its extension, so a PDF, a renamed HTML page, or a truncated export is rejected at the picker rather than eight checks later. Its dimensions are read from the header, and the viewport is inferred from the width — that is what tells the agent which capture is the desktop layout and which ones only qualify how it reflows. Screenshots taken *on* a phone or tablet are recognised as such rather than being mistaken for desktop captures, since a device screenshot is 2–3× its CSS width.

PNG, JPG, WebP and GIF are accepted. **HEIC and AVIF are refused**, with a message saying so: they are real images, but an agent cannot open one, and an iPhone screenshot dragged straight off a Mac is HEIC. Convert it to PNG first.

The accepted images are then copied into `.claude/tmp/<project>/pages/<page-slug>/reference/`, beside the page's own notes. The build therefore does not depend on your Downloads folder still holding them — and re-running the same page for the same project reuses that set automatically, with nothing to upload again.

### Several pages in one run

A PM hands over a set of designs, not one. **Add another page** appends a block, and every block is a page: its own name, its own reference kind, its own reference, its own notes.

```
PAGE 1                                                            Remove
Page Name          [ Contact Us ]
Reference          ● Figma   ○ Custom HTML  ○ Screenshot
Figma Link         [ https://www.figma.com/design/7Kq2/…?node-id=140-22 ]

PAGE 2                                                            Remove
Page Name          [ About Us ]
Reference          ○ Figma   ○ Custom HTML  ● Screenshot
Screenshots        [ Choose Files ]   2 ready
                   about-desktop.png   DESKTOP  1440×3200 · 412 KB
                   about-mobile.png    MOBILE    390×2100 · 180 KB

PAGE 3                                                            Remove
Page Name          [ Pricing ]
Reference          ○ Figma   ● Custom HTML  ○ Screenshot
Custom HTML Path   [ /Users/you/Downloads/pricing.zip ]

[ Add another page ]   3 pages — built in this order, in one Claude Code session,
                       against one resolved architecture.
[ Start Building 3 Pages ]
```

The kinds mix freely: a Figma frame for one page, screenshots for the next, an HTML export for a third. Each page is validated on its own — the checks are labelled `Page 2 · About Us — Reference verified`, so a bad link names the design it came from — and each gets its own notes directory, its own reference copy and its own history entry.

One prompt comes out, listing every page. That is the point of batching: resolving the WordPress root, reading the content, and deriving the architecture from the indexes is identical for all of them, so the agent pays for it once and then runs phases 3–14 per page. Component descriptions accumulate as it goes, so page three normally costs meaningfully less than page one.

Two limits, both enforced by the server:

| Rule | Why |
| :-- | :-- |
| At most 12 pages per run | each one is a full fourteen-phase build in a single Claude Code session; past a dozen the run is a context window someone abandons halfway |
| No two pages whose names slugify the same | the slug *is* the notes directory, the history entry and the progress file — `Contact Us` and `contact-us` would silently overwrite each other |

A single page needs no decision: the form opens with one block and looks exactly as it always did.

**Additional Notes** is optional, appears for every reference kind, is per page, and is the one field the launcher does not interpret. Whatever you type is reproduced in the prompt verbatim, introduced as instructions that outrank the reference wherever the two disagree — which is what makes it the right place for intent a design cannot carry: which existing component to reuse, what in the mockup is a placeholder, which section to leave out of this pass. It is capped at 2,000 characters, since every one of them is paid for on each run, and a counter appears once you are near the limit. The notes are stored with the page's history entry, so re-running the same page does not mean retyping them.

The **live reference URL** is optional and only appears for this kind. Give it when the page already exists somewhere — live, staging, or a dev host — and the agent can open it to settle exact copy, real spacing, font stacks and image dimensions: everything a screenshot can only suggest. It stays a *reference*; its markup is never copied into your site.

Submitting registers the project, builds its intelligence, and prints the prompt. On a real 54-page site that takes about 2.5 seconds.

### Existing Project

```
Select Existing Project  [ Acme Website ▼ ]

Project: Acme Website            fresh
Project Path:   /Users/.../acme
Platform:       WordPress
Builder:        Elementor
Theme:          Astra Child (child theme)
Pages Indexed:  42
Content Source: local database
Components:     11 described of 63 found
Last Indexed:   Aug 20, 2026

[ Refresh Site Intelligence ]     Explicit only — Start Building never re-scans.
```

You never re-enter the path. Fill in the page name and the reference, and go. A stale cache is labelled with the reason, and is still used — refreshing is your call.

### WordPress root resolution

The Project Path you enter is the **root of the search**, not necessarily the WordPress root. The launcher looks for core files (`wp-config.php`, `wp-load.php`, `wp-settings.php`, `wp-includes/`, `wp-admin/`) in that directory, then one and two levels beneath it, and takes the shallowest match — so pointing at `…/gospotlight.co` correctly resolves to `…/gospotlight.co/www`.

Detection is **by files, never by directory name**. `www`, `public`, `public_html`, `web`, `htdocs`, `app/public` are only conventions; a folder is the root because it holds WordPress, whatever it is called. Rules:

- **Never searches above the path you gave**, and never infers the root from a Git repository — a repo frequently wraps the install in a subdirectory, or holds several sites.
- **Never descends into `wp-content/`** — backup and migration plugins keep whole WordPress copies there, and matching one would point the pipeline at a snapshot instead of the live site.
- **Skips** `.git/`, `node_modules/`, `vendor/`, and dot-directories.
- **Refuses to guess** when two installs sit at the same depth; it lists them and asks you to pick.
- **Flags a `wp-content`-only checkout** rather than calling it an install — the agent can read the theme, but the QA phases cannot load a site with no core.

The resolved path is what goes into the generated prompt, and the UI says plainly when it differs from what you typed.

### Validation

Every ✓ is a real filesystem or database result, never an assumption:

```
✓ Validating inputs          All fields present and well-formed.
! WordPress root resolved    Found 1 level down at …/gospotlight.co/www, not at the path
                             you entered. This resolved path is what goes into the prompt.
✓ Pages in this run          2 pages — Contact Us, About Us. They are built in this order,
                             in one session, against one resolved architecture.
✓ Page 1 · Contact Us — Page name           Contact Us
! Page 1 · Contact Us — Reference verified  Figma link format is valid. Note: the Figma MCP
                             connector must be authorized, or the agent cannot read the design.
✓ Page 2 · About Us — Reference verified    2 images (592 KB) — about-desktop.png 1440×3200,
                             about-mobile.png 390×2100. Viewports inferred from width.
✓ Project registered         Created .claude/tmp/acme-website/ — this project's
                             intelligence is isolated from every other project.
✓ WordPress content          local database via mysql client (mamp) via socket …
                             No XML export was needed.
✓ Site intelligence built    70 pages, 26 candidate components, theme ss_theme,
                             builder Gutenberg — written in 3.0s
✓ Existing session found     1 session for this project. Most recent: 6006efe4…
```

**Session detection** tells you whether to resume or start fresh. It works by reading the `cwd` recorded inside each session transcript in `~/.claude/projects/`, *not* by decoding the directory names — those collapse `/`, `.`, and spaces all to `-`, so they are ambiguous and cannot be reversed reliably.

The server must be running while you use the page. **A `file://` page cannot start it** — browsers forbid a web page from launching a process. If you do open the HTML directly, the page detects it: when the server happens to be running it redirects you, and when it is not it tells you what to run rather than failing with a bare `Failed to fetch`. Bookmark `http://127.0.0.1:4599`, not the file path.

### Recovering from a broken registry

`projects.json` is an **index**, not the source of truth — every project also keeps its own `project.json`. So:

| What went wrong | What happens |
| :-- | :-- |
| `projects.json` missing | rebuilt from the project directories |
| `projects.json` truncated or unparseable | rebuilt, and the repair is recorded in the file |
| `projects` is not an array | rebuilt |
| A listed project's directory is gone | dropped from the list, with a note |
| A project id contains `../` | rejected outright |
| The project *path* no longer exists | listed, flagged, and blocked from Start Building with an actionable message |
| Same path registered twice | reuses the existing intelligence directory, and keeps the existing name |

---

## Importing legacy handoff files

An earlier generation of this tool wrote flat handoffs — `.claude/tmp/<slug>-architecture.md` and `<slug>-design-spec.md`. Those are real work product, so the launcher offers to import them rather than leaving them behind. It appears as a banner when any are found.

Importing:

- creates or matches a project from the `Provided Path` / `WordPress Root` recorded in the file's header
- copies the inventory to `<project>/site-intelligence/legacy-inventory.md` and the design spec into `pages/`
- **redacts credentials on the way in.** The old inventory prompt asked the scout to record "wp-config.php notable constants", and in practice that wrote live database passwords into a plain-text file. Those lines are stripped, and the banner at the top of the copy says which keys were redacted.
- **deletes and moves nothing.** The originals stay exactly where they were found, and a ledger keeps the import idempotent.
- marks the project as needing a refresh — unless it already has current intelligence, in which case the import is just added context.

A bare payload works too: one with no `mode` and no project name is treated as a new-or-matched project, with the name derived from the directory.

---

## Step-by-step usage

### Step 1 — Generate the prompt

Use the launcher, which validates everything and builds the intelligence first. The prompt it produces is short by design:

```
Use the page-builder agent.

Project: Acme Website  (id: acme-website)
Project path: /Users/.../acme
WordPress root: /Users/.../acme/www   <- resolved by marker search; use this for file operations
Page name: Contact Us
Page notes: /Users/.../.claude/tmp/acme-website/pages/contact-us
Reference: Figma — https://www.figma.com/design/…

Site intelligence: /Users/.../.claude/tmp/acme-website/site-intelligence
Status: FRESH (0d old) — trust it
Cached: content from the local database · 70 pages indexed · builder in use: Gutenberg ·
        theme: ss_theme · 11/26 components described
Pages already built for this project: 3 (most recent: About Us, Services, FAQ)

Read `manifest.md` in the intelligence directory FIRST. It says which file answers which question.
Do not re-inventory the install, do not catalogue every component, and do not read the plugins directory for context.
Find the closest existing page from `pages-index.json` before opening any source file.
```

That `Status:` line is the one that decides what the run costs.

A run carrying several pages replaces the single `Page name:` line with a numbered list, and says what is shared between them:

```
Pages to build: 3 — all of them, in this one run, in the order listed.
  Phases 1 and 2 are project-level: read the intelligence and resolve the architecture ONCE, then reuse
  that conclusion for every page. Phases 3-14 run per page, each against its own page notes directory and
  its own progress.json. Component descriptions a page pays for stay in component-index.json, so later
  pages in this batch should start cheaper than earlier ones.
  Do not stop between pages for approval. Stop only for a genuine ambiguity, and say which page it is about.

Page 1 of 3: Contact Us
  Page notes: /Users/.../.claude/tmp/acme-website/pages/contact-us
  Reference: Figma — https://www.figma.com/design/…

Page 2 of 3: About Us
  Page notes: /Users/.../.claude/tmp/acme-website/pages/about-us
  Reference: Screenshot — 2 images in /Users/.../pages/about-us/reference
    - 01-desktop-about-desktop.png  1440×3200  (desktop)
    - 02-mobile-about-mobile.png  390×2100  (mobile)
  ...

Page 3 of 3: Pricing
  Page notes: /Users/.../.claude/tmp/acme-website/pages/pricing
  Reference: Custom HTML — /Users/you/Downloads/pricing.zip
```

Everything below that block — the intelligence status, the cache summary, the tools — is written once, because it is the same for every page.

A screenshot reference expands the `Reference:` line into the images themselves, so the agent knows which capture is which before it opens one:

```
Page name: Contact Us
Reference: Screenshot — 3 images in /Users/.../.claude/tmp/acme-website/pages/contact-us/reference
  - 01-desktop-hero-desktop.png  1440×4200  (desktop)
  - 02-tablet-tablet.png  834×3900  (tablet)
  - 03-mobile-mobile.png  390×3800  (mobile)
Live reference URL: https://staging.acme.com/contact
  The same page already exists there. Use it to confirm exact copy, real spacing, fonts and asset URLs —
  it settles what a screenshot can only suggest. Read it as a reference; do not copy its markup into this site.
The screenshots are the source of truth for what this page looks like. They carry NO structured design data:
  ...
```

The instruction block that follows is not padding: it is what stops an agent reporting measured pixel values as if they were given design tokens.

### Step 2 — Check the Detection Summary

The orchestrator loads the cache and reports theme, builder, relevant builder, ACF, CPTs, CSS architecture, and its closest-page ranking. To force the checkpoint:

```
Before implementing, show me the WordPress Detection Summary for this project.
```

Check the **installed vs. actually used** counts. If Elementor is active but only 2 of 40 pages carry `_elementor_data`, the site is not an Elementor site. Partially-migrated sites are where this call most often goes wrong — which is why the content index reports both numbers separately.

Also check `determinedBy` on the theme. Without database access the launcher *infers* the active theme (a lone child theme naming an installed parent is a strong signal, but it is still an inference), and says so.

### Step 3 — Review the closest-page shortlist

Worth a look, because everything after it is scoped by it:

```
Show me the closest existing pages you picked, and why.
```

If it picked wrong, this is the cheapest possible moment to say so:

```
The closest page is actually [page] — [reason].
```

### Step 4 — Review the Reuse Decision Table

```
Show me the Reuse Decision Table before implementing.
```

Look for `NEW` verdicts. Each one is a component about to be written from scratch, and each must name what was checked and why it did not fit. If you know the site already has something close:

```
Row 7 shouldn't be NEW — the pricing block on /plans is close enough to extend.
```

Every reference section must have a row. A missing row means a section nobody accounted for. The table is **binding** on the implementer.

### Step 5 — Let wp-implementer build

Two things it may report instead of building, and neither should be waved through:

- The **intelligence contradicts the actual code** — a cached fact or an upstream judgment is wrong. It names the file and field; fix it there rather than working around it, or it will keep costing runs.
- A **decision-table verdict cannot be honored** — the named component does not exist or genuinely cannot be extended. Fix the row rather than telling it to build new anyway.

Its report ends with a `Source files opened` count. A small, deliberate number is evidence the indexes did their job.

### Step 6 — Let wp-visual-qa run the fix loop

It validates locally (page loads, correct template, ACF resolves, no PHP or console errors, existing pages unaffected), then compares section-by-section at desktop, tablet, and mobile.

It sorts every difference into **DEFECT**, **INTENTIONAL** (the site's design system legitimately differs from the reference), and **REFERENCE ARTIFACT** (the reference is impossible or hallucinated). Only DEFECTs get fixed. Root causes only — no `!important`, no magic pixel values, no negative-margin nudges.

### Step 7 — Read the report

The `## Cost profile` block is new:

```
## Cost profile
- Components in index: 63 | described this run: 9
- Source files opened: 14
- Intelligence reused: yes — architecture, content indexes, 11 prior component descriptions
```

If it inspected every component and opened hundreds of files, the run cost what a full rediscovery costs and the cache bought nothing. And read **QA Rounds** honestly: if it stopped at round 4 with defects open, they are listed there — that is the honest outcome, not a failure to hide.

### Step 8 — Next page

```
Yes — same project. Pages: Contact Us, About Us. References: [Figma links / HTML paths / screenshots].
```

No path, no re-scan, no re-inventory. The cache loads, the closest page is found from the index, and only the new sections' components get described — including anything page one added. For a different project, use the launcher's Existing Project list, or register a new one. Architecture conclusions are never carried across projects.

---

## Why it doesn't launch VS Code for you

The original plan was one-click: open VS Code, resume the Claude session, inject the prompt. That is not reliably possible, and the reasons are worth recording so nobody re-attempts it:

- **The VS Code extension can't be driven.** `anthropic.claude-code` declares no `uriHandler` and no `onUri` activation event, so `vscode://` deep links don't reach it. Its commands are palette/keybinding-only, and the VS Code CLI has no flag to execute an extension command.
- **The desktop app can't either.** Claude Desktop's Code tab is interactive by design — the docs map `--resume`/`--continue` to *"click a session in the sidebar"* and state that `--print`/`--output-format` are *"not available. Desktop is interactive only."* A `claude-cli:` URL scheme is registered on macOS, but it appears nowhere in the documentation, so building on it would mean depending on an unpublished interface.
- The only remaining routes were GUI automation (explicitly rejected) or auto-running tasks written into the client's WordPress project (violates the no-stray-files rule).

**Documented mechanisms that do exist**, if you want them manually:

| Goal | Command |
| :-- | :-- |
| Resume this project's session | `claude --continue` in the project directory |
| Pick from a list | `claude --resume` |
| Connect a terminal session to VS Code | `claude --ide` |
| Move a running CLI session into Desktop | `/desktop` |

`--continue` is directory-scoped and starts a fresh conversation when none exists, so it is safe to use unconditionally.

---

## Reading the design reference

**HTML ZIP** — works directly. The scout extracts it to scratch (never into your WordPress project) and reads the real DOM, plus any CSS custom properties or Tailwind config shipped with it.

**Figma** — requires the Figma MCP connector to be **authorized**, in your claude.ai connector settings. Without it, a Figma *link* is just a URL the agent cannot open. If the scout cannot read structured design data it reports that rather than guessing, and the orchestrator stops and asks you for an export instead of building a decision table against a page it cannot see.

**Screenshots** — work with nothing installed, and are the fallback for when there is no Figma file and no export: a design someone sent as a PNG, a competitor page, a print-screen of a staging site. The trade-off is real and the pipeline is explicit about it rather than papering over it.

A screenshot carries **no** layer names, **no** spacing values, **no** tokens, and nothing at all about states or interaction. So the agents are told to:

- **measure as ratios and map onto the site's own scales.** A capture may be retina, so a 96px gap in the image is quite possibly 48 CSS px. Landing on an existing spacing-scale step is the goal; a hard-coded pixel value that matches the screenshot exactly is a defect.
- **take from the site whatever the image cannot show** — hover and focus states, transitions, carousel behaviour, form validation — and say in the report which behaviours came from the site rather than the reference.
- **mark what is genuinely not visible as `UNCLEAR`** instead of inferring it. A cut-off fold, an unreadable caption, or a row that might be a grid or a carousel is raised with you before the build starts, and comes back as `UNVERIFIED` in the QA report rather than a false pass.
- **never invent a section no screenshot shows.**

Give one capture per viewport you care about. Desktop alone produces a desktop-correct page whose mobile behaviour is entirely the site's existing defaults — which is often fine, but it should be a decision rather than a surprise. Adding the live reference URL removes most of the ambiguity, and is worth doing whenever the page exists anywhere you can reach.

---

## Tuning cost vs. quality

**Cheapest first knob — `effort`, not model.** Every agent file accepts `effort: low | medium | high | xhigh | max`. Same model, more reasoning. Before escalating a phase to a bigger model, try raising its effort.

**Component descriptions too shallow?** If `renders` values read like restated filenames instead of visual descriptions, matching quality collapses and you will see spurious `NEW` verdicts. Raise the `TARGETED` dispatch to `model: opus` in [page-builder.md](.claude/agents/page-builder.md) — one word in the Model routing table, and the highest-return upgrade for a component-heavy site. It is also cheap, because it describes a shortlist rather than the whole site.

**Too many recon errors?** Change `model: haiku` to `model: sonnet` in [wp-scout.md](.claude/agents/wp-scout.md). Recon is where a cheap model does the most damage if it guesses.

**Want Opus reviewing every build?** Send `wp-visual-qa` in `FIX` mode from round 1. Understand the trade-off first — see *The escalation ladder*.

⚠️ **Do not set `CLAUDE_CODE_SUBAGENT_MODEL`.** It sits above per-invocation parameters and frontmatter in the resolution order, so setting it silently forces *every* agent here onto one model and collapses the entire routing scheme with no warning.

Related: `CLAUDE_CODE_MAX_SUBAGENT_SPAWN_DEPTH` defaults to 3 layers. This pipeline uses 2 (page-builder → worker), so the default is fine — but setting it to `1` would disable the pipeline.

---

## Guardrails

- Never replace the site's existing page builder, theme, or CSS architecture.
- Never delete existing templates, remove plugins, or duplicate existing components.
- Never modify unrelated pages or change existing URLs unnecessarily.
- Reuse existing ACF field groups and components before creating new ones — enforced by the binding Reuse Decision Table, not left to the implementer's discretion.
- Never conclude a builder is "the site's builder" from installation alone; usage counts decide.
- Treat existing code as production-quality; fix root causes rather than layering CSS overrides.
- `wp-scout` is strictly read-only against the WordPress project, and may write only inside the project's own intelligence directory.
- **Nothing is ever written inside the client's WordPress install** except the page itself.
- Credentials are read only to connect, never persisted, never logged, never placed in a file an agent reads, and stripped out of anything imported from a legacy handoff.

## Before you start

The agents read and write wherever they are told. Double-check the project path the first time you register a project — after that, the launcher remembers it, which is one fewer chance to point a run at the wrong tree.
