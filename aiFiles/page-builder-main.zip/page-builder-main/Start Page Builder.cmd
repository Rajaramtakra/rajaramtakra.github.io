@echo off
REM
REM Windows - double-click this file to start the Page Builder launcher
REM and open it in your browser.
REM
REM This wrapper only has one job: find Node. All the real logic is in
REM launcher\start.js, which is shared with macOS and Linux.

setlocal
set "DIR=%~dp0"

where node >nul 2>&1
if errorlevel 1 goto :nonode

node "%DIR%launcher\start.js"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo.
  echo   Press any key to close...
  pause >nul
)
exit /b %RC%

:nonode
echo.
echo   x  Node.js was not found.
echo.
echo      Install it from https://nodejs.org, then double-click this file again.
echo      Make sure "Add to PATH" is ticked during installation.
echo.
echo   Press any key to close...
pause >nul
exit /b 1
