# Configuration

How this project is wired: what the Claude Code harness loads and from where,
the deterministic scripts and file contracts around it, and what is
deliberately left unconfigured — plus, at the end, what is still missing.

**Despite the name, nothing here is loaded by anything.** Every consumer — the
harness, the launcher, the agents — reads its real configuration from a
specific path by convention, so moving a live setting into this file would
silently switch it off. Each section names the file that is authoritative.

---

## What the harness loads

| Piece | Authoritative location | Status |
| :-- | :-- | :-- |
| Subagents | `.claude/agents/*.md` | 4 defined |
| Permissions (personal) | `.claude/settings.local.json` | 3 entries |
| Permissions (shared) | `.claude/settings.json` | 4 entries — the `tools/` scripts |
| Auto-loaded project context | `CLAUDE.md` | present — cache rules, the files never to read, conventions |
| Hooks | `settings.json` → `hooks` | none, deliberately |
| Skills | `.claude/skills/` | none |
| Slash commands | `.claude/commands/` | none |
| MCP servers | user-level config | Figma, used by the reference-reading phases — not needed for the HTML or screenshot reference kinds |
| Entry-point prompt | `launcher/lib/prompt.js` | generated per run |

### Why the agent definitions cannot move into this file

The harness discovers subagents by reading `.claude/agents/*.md` and parsing
each file's frontmatter. The body of each file **is that agent's prompt** — it
is what the agent is told when it is spawned. Consolidating those bodies here
would mean the agents never receive their instructions, which is not a
refactor but a deletion. Same for `settings.local.json`: it is machine-read
JSON, and prose in a Markdown file is not a substitute for it.

So: behaviour stays in the agent files, machine config stays in JSON, and this
file explains the shape of the whole thing in one place.

---

## The four agents

| Agent | Model | Effort | Tools | Dispatched by | Phases |
| :-- | :-- | :-- | :-- | :-- | :-- |
| `page-builder` | inherit | — | all | the user (entry point) | orchestrates 1–14 |
| `wp-scout` | haiku | — | Read, Grep, Glob, Bash, Write, WebFetch | `page-builder` | RECON, and 4 |
| `wp-implementer` | sonnet | — | all | `page-builder` | 6–11, and fix rounds |
| `wp-visual-qa` | opus | high | all | `page-builder` | 12–14 |

The tiering is the cost model: reconnaissance is cheap and mechanical, building
is mid-tier, and **judging whether the page matches the design is the expensive
part** — so `wp-visual-qa` gets the strongest model and the only `effort: high`.

### The one deliberate model override

Every child's model comes from its own frontmatter, and `page-builder` is told
not to pass a `model` parameter — **with one exception**: the Phase 4
`TARGETED` dispatch of `wp-scout` passes `model: sonnet`, because describing
what a component renders needs more than the `haiku` default that RECON's
gap-filling is sized for. That exception is stated in
[page-builder.md](.claude/agents/page-builder.md); anywhere else, an explicit
`model` overrides a tier that was chosen on purpose.

### `wp-scout` is the only tool-restricted agent

`tools: Read, Grep, Glob, Bash, Write, WebFetch` — it is read-only with respect
to the WordPress project and may write only to the intelligence directory and
its own scratch space. It keeps `Bash` because it needs it to run the scripts
below, and `WebFetch` so that a screenshot reference's optional live URL can
actually be read — that URL is the only thing that settles copy and real
spacing when the reference is pixels.

---

## Deterministic scripts — the contract

[tools/](tools/) holds work that is **not** Claude's job. Both scripts are
dependency-free Node, behave identically on macOS, Windows and Linux, and are
named with their absolute path in the generated prompt (Claude Code's working
directory is the WordPress project, not this folder, so a relative path would
not resolve).

### `verify-page.js` — Phase 12

Checks, exactly: page status · WordPress's critical-error page · PHP
diagnostics in output · every local script, stylesheet, image and `srcset`
variant · the homepage and each `--baseline` page · `wp-content/debug.log` and
whether it is recent enough to belong to this build. Exit 0 = all passed.

**Does not check**, and the agent is told so explicitly: template/builder
resolution, ACF fields rendering real values, JavaScript console errors, or
anything visual. A 200 proves something rendered, not that the right thing did.

### `query-index.js` — the indexes, compressed

**Compression, not delegation.** Every page and every component is still
listed; only redundancy is removed. `--like` reorders by a printed, arguable
score and never truncates. `--limit` hides rows and reports how many, which is
fine for reporting and wrong for a decision — so the agents are told not to
pass it while choosing.

### `progress.json` — the phase report

`page-builder` overwrites `<page notes>/progress.json` before entering each
phase: `{ phase, label, state, qaRounds, note, updatedAt }`. The launcher reads
it, falls back to inferring from artifacts on disk when it is absent, and
resolves conflicts by **timestamp, not phase number**. Contract lives in
[page-builder.md](.claude/agents/page-builder.md), reader in
[launcher/lib/progress.js](launcher/lib/progress.js).

---

## Permissions

`.claude/settings.local.json` is personal and not shared, so anything needed by
every run belongs in `.claude/settings.json` instead. The two scripts above are
invoked on essentially every build, and without an allowlist entry each call
raised an approval prompt mid-pipeline — so `.claude/settings.json` now allows
exactly those two, quoted and unquoted:

```
Bash(node "<install>/tools/query-index.js" *)
Bash(node "<install>/tools/verify-page.js" *)
```

**These name a specific install path.** Permission rules match by prefix, and
the prompt invokes the scripts by absolute path, so there is no portable form.
Nothing breaks when they are wrong — which is the problem: a clone starts
cleanly, and the stale paths surface much later as approval prompts
interrupting a build.

So they are **repaired automatically**. Every launcher start runs
[launcher/lib/preflight.js](launcher/lib/preflight.js), which rewrites these
four rules to match the install's own location, preserving any other rules in
the file. A correct install is not written to and prints nothing. An
unparseable `settings.json` is copied to `settings.json.bak` before being
replaced, so hand-written rules are recoverable.

Deliberately **not** `Bash(node *)`, which would allow arbitrary code
execution through the interpreter.

Read-only `wp` subcommands (`wp plugin list`, `wp theme list`, `wp post list`,
`wp option get`, and `wp db query` with `SELECT` only) are sanctioned by
[wp-scout.md](.claude/agents/wp-scout.md); anything that writes to the database
or the WordPress project is not.

---

## Not configured, deliberately

- **No hooks.** Nothing in this pipeline needs to fire on every tool call, and
  a hook that shells out on each one would cost more than it saves.
- **No skills or slash commands.** The entry point is the launcher-generated
  prompt, which carries the project id, paths and intelligence status. A slash
  command would have to re-derive all of that.
- **No committed MCP config.** Figma is authorised per user; pinning a server
  here would break for anyone who has not authorised it.

---

## Gaps

- **No tests.** Nothing in `launcher/` or `tools/` has an automated test; every
  check in this session was run by hand. For a tool that writes into client
  WordPress installs, that is the largest remaining gap.
- **~~Not under version control.~~** Now a git repo, pushed to
  `smartsites-nepal/page-builder` (private). `.claude/tmp/` is ignored except
  for a `.gitkeep`, so the directory arrives empty on a clone and no client
  data is tracked; `.claude/settings.local.json` and the `.DS_Store` files are
  ignored too, and `.claude/settings.json` is committed.
- **`launcher/server.log` is never rotated.**

---

## Verifying the wiring

```bash
# agents parse and declare what this file claims
for f in .claude/agents/*.md; do echo "$f"; sed -n '2,6p' "$f" | grep -E '^(name|model|effort|tools):'; done

# scripts run and exit cleanly
node tools/query-index.js pages --project <id> | head -3
node tools/verify-page.js --project <id> --page <slug>; echo "exit=$?"

# the prompt names the tools directory with an absolute path
grep -n "TOOLS_DIR" launcher/lib/prompt.js

# the preflight agrees this install is healthy (silence = pass)
node -e "console.log(require('./launcher/lib/preflight').run().join('\n') || '(healthy)')"
```
