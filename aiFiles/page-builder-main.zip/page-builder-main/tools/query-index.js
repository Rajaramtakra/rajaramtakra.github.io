'use strict';

/**
 * Compact views over the site-intelligence indexes.
 *
 * The indexes are written for completeness — absolute paths, full SEO titles,
 * every URL — which is right for a file on disk and wrong for a context
 * window. `pages-index.json` is 41 KB on a 54-page site and an agent reads it
 * whole in Phase 3 just to pick a handful of comparable pages.
 *
 * This is **compression, not delegation.** Every page and every component is
 * still listed; only the redundancy is removed — paths relativised against the
 * WordPress root, nulls dropped, long titles trimmed. The agent still makes
 * the judgment, and still sees every candidate while making it, so nothing it
 * could previously have chosen has become invisible.
 *
 * `--like` adds a deterministic similarity score as an ordering convenience.
 * It reorders; it never truncates. The full count is always printed, and
 * anything hidden by an explicit `--limit` is reported as hidden.
 *
 * Usage:
 *   node tools/query-index.js pages      --project <id> [--like <slug>] [--kind k] [--limit n]
 *   node tools/query-index.js components --project <id> [--min-usage n] [--grep re] [--limit n]
 *   ... --json
 */

const fs = require('node:fs');
const path = require('node:path');

const APP_ROOT = path.resolve(__dirname, '..');

function intel(project, file) {
  const f = path.join(APP_ROOT, '.claude', 'tmp', project, 'site-intelligence', file);
  if (!fs.existsSync(f)) return null;
  try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; }
}

function parseArgs(argv) {
  const out = { limit: 0, json: false };
  out.what = argv[0];
  for (let i = 1; i < argv.length; i++) {
    const a = argv[i];
    const val = () => argv[++i];
    if (a === '--project') out.project = val();
    else if (a === '--like') out.like = val();
    else if (a === '--kind') out.kind = val();
    else if (a === '--grep') out.grep = val();
    else if (a === '--min-usage') out.minUsage = Number(val()) || 0;
    else if (a === '--limit') {
      const raw = val();
      const n = Number(raw);
      // A negative limit reached `slice(0, -n)`, which silently dropped the
      // LAST n rows while reporting them as "hidden" — the exact accuracy
      // failure these views exist to avoid.
      if (!Number.isInteger(n) || n < 1) return { error: `--limit must be a whole number of 1 or more (got "${raw}")` };
      out.limit = n;
    }
    else if (a === '--json') out.json = true;
    else if (a === '--help' || a === '-h') out.help = true;
    else return { error: `unknown argument: ${a}` };
  }
  return out;
}

/* ----------------------------------------------------------------- scoring */

/** Overlap of two element lists, 0..1. */
function jaccard(a, b) {
  const A = new Set(a || []);
  const B = new Set(b || []);
  if (!A.size && !B.size) return 0;
  let hit = 0;
  for (const x of A) if (B.has(x)) hit++;
  return hit / (A.size + B.size - hit);
}

/** Closeness of two numbers, 0..1, tolerant of zero. */
function near(a, b) {
  const x = Number(a) || 0;
  const y = Number(b) || 0;
  if (!x && !y) return 1;
  return 1 - Math.abs(x - y) / Math.max(x, y, 1);
}

/**
 * Structural similarity to a reference page. Deliberately transparent —
 * the weights are printed with the score so a surprising ordering can be
 * argued with rather than taken on faith.
 */
function score(page, ref) {
  const parts = {
    elements: jaccard(page.signature && page.signature.elements, ref.signature && ref.signature.elements) * 0.45,
    kind: (page.kind === ref.kind ? 1 : 0) * 0.2,
    builder: (page.builder === ref.builder ? 1 : 0) * 0.15,
    sections: near(page.signature && page.signature.sectionCount, ref.signature && ref.signature.sectionCount) * 0.1,
    words: near(page.signature && page.signature.wordCount, ref.signature && ref.signature.wordCount) * 0.1,
  };
  const total = Object.values(parts).reduce((a, b) => a + b, 0);
  return { total, parts };
}

/* ------------------------------------------------------------------- pages */

function pages(opts) {
  const idx = intel(opts.project, 'pages-index.json');
  if (!idx) return { error: `No pages-index.json for project ${opts.project}` };

  let rows = idx.pages || [];
  const totalAll = rows.length;

  if (opts.kind) rows = rows.filter((p) => p.kind === opts.kind);
  const afterFilter = rows.length;

  let ref = null;
  if (opts.like) {
    ref = (idx.pages || []).find((p) => p.slug === opts.like);
    if (!ref) return { error: `No page with slug "${opts.like}" — cannot rank against it.` };
    rows = rows
      .filter((p) => p.slug !== ref.slug)
      .map((p) => ({ p, s: score(p, ref) }))
      .sort((a, b) => b.s.total - a.s.total)
      .map((x) => ({ ...x.p, _score: x.s }));
  }

  const shown = opts.limit ? rows.slice(0, opts.limit) : rows;

  return {
    project: opts.project,
    source: idx.source || null,
    totalPages: totalAll,
    matchedFilter: afterFilter,
    shown: shown.length,
    hidden: rows.length - shown.length,
    rankedAgainst: ref ? { slug: ref.slug, kind: ref.kind, builder: ref.builder,
      sections: ref.signature && ref.signature.sectionCount,
      words: ref.signature && ref.signature.wordCount,
      elements: (ref.signature && ref.signature.elements) || [] } : null,
    pages: shown.map((p) => ({
      id: p.id,
      slug: p.slug,
      kind: p.kind,
      template: p.template,
      builder: p.builder,
      sections: (p.signature && p.signature.sectionCount) || 0,
      words: (p.signature && p.signature.wordCount) || 0,
      elements: (p.signature && p.signature.elements) || [],
      ...(p._score ? { score: Number(p._score.total.toFixed(3)) } : {}),
    })),
  };
}

/* -------------------------------------------------------------- components */

function components(opts) {
  const idx = intel(opts.project, 'component-index.json');
  if (!idx) return { error: `No component-index.json for project ${opts.project}` };
  const arch = intel(opts.project, 'architecture.json') || {};
  const wpRoot = (arch.paths && arch.paths.wpRoot) || '';

  // Absolute paths are the single biggest redundancy in this file: the same
  // long prefix on every component's `path` and on each of its `includedBy`.
  const rel = (p) => {
    if (!p) return null;
    let out = wpRoot && p.startsWith(wpRoot) ? p.slice(wpRoot.length) : p;
    out = out.replace(/\\/g, '/').replace(/^\/+/, '');
    return out.replace(/^wp-content\/(themes|plugins)\//, '');
  };

  let rows = idx.components || [];
  const totalAll = rows.length;

  if (opts.minUsage) rows = rows.filter((c) => (c.usedOnPages || []).length >= opts.minUsage);
  if (opts.grep) {
    let re;
    try { re = new RegExp(opts.grep, 'i'); } catch { return { error: `bad --grep pattern: ${opts.grep}` }; }
    rows = rows.filter((c) => re.test(c.name || '') || re.test(c.renders || ''));
  }
  const matched = rows.length;

  // Proven components first: something rendering on six pages is a safer
  // reuse candidate than something rendering nowhere.
  rows = rows.slice().sort((a, b) =>
    (b.usedOnPages || []).length - (a.usedOnPages || []).length
    || (b.includedBy || []).length - (a.includedBy || []).length);

  const shown = opts.limit ? rows.slice(0, opts.limit) : rows;

  return {
    project: opts.project,
    totalComponents: totalAll,
    matchedFilter: matched,
    shown: shown.length,
    hidden: rows.length - shown.length,
    inspected: (idx.counts && idx.counts.inspected) || 0,
    bySource: (idx.counts && idx.counts.bySource) || {},
    pathsRelativeTo: wpRoot || null,
    components: shown.map((c) => ({
      id: c.id,
      name: c.name,
      source: c.source,
      file: rel(c.path),
      usedOnPages: (c.usedOnPages || []).length,
      includedBy: (c.includedBy || []).length,
      ...(c.renders ? { renders: c.renders } : {}),
      ...(c.inspected ? { inspected: true } : {}),
    })),
  };
}

/* ------------------------------------------------------------------ output */

function pad(s, n) { s = String(s == null ? '' : s); return s.length > n ? s.slice(0, n - 1) + '…' : s.padEnd(n); }

function printPages(r) {
  const out = [];
  out.push(`pages: ${r.totalPages} total`
    + (r.matchedFilter !== r.totalPages ? `, ${r.matchedFilter} matched filter` : '')
    + (r.hidden ? `, ${r.hidden} hidden by --limit` : '')
    + (r.source ? `  (content from ${r.source})` : ''));
  if (r.rankedAgainst) {
    const a = r.rankedAgainst;
    out.push(`ranked against ${a.slug}: kind=${a.kind} builder=${a.builder} sections=${a.sections} words=${a.words}`);
  }
  out.push('');
  out.push(`${r.rankedAgainst ? 'score ' : ''}${pad('slug', 30)} ${pad('kind', 12)} ${pad('builder', 11)} ${pad('sec', 4)} ${pad('words', 6)} elements`);
  for (const p of r.pages) {
    const els = p.elements.length ? p.elements.slice(0, 6).join(',') + (p.elements.length > 6 ? `,+${p.elements.length - 6}` : '') : '-';
    out.push(`${r.rankedAgainst ? pad(p.score.toFixed(2), 6) : ''}${pad(p.slug, 30)} ${pad(p.kind, 12)} ${pad(p.builder, 11)} ${pad(p.sections, 4)} ${pad(p.words, 6)} ${els}`);
  }
  return out.join('\n') + '\n';
}

function printComponents(r) {
  const out = [];
  out.push(`components: ${r.totalComponents} total`
    + (r.matchedFilter !== r.totalComponents ? `, ${r.matchedFilter} matched filter` : '')
    + (r.hidden ? `, ${r.hidden} hidden by --limit` : '')
    + `, ${r.inspected} described`);
  out.push(`by source: ${Object.entries(r.bySource).map(([k, v]) => `${k}=${v}`).join(' ')}`);
  if (r.pathsRelativeTo) out.push(`paths relative to ${r.pathsRelativeTo} (and wp-content/themes|plugins stripped)`);
  out.push('');
  out.push(`${pad('id', 6)} ${pad('used', 5)} ${pad('incl', 5)} ${pad('source', 20)} file`);
  for (const c of r.components) {
    out.push(`${pad(c.id, 6)} ${pad(c.usedOnPages, 5)} ${pad(c.includedBy, 5)} ${pad(c.source, 20)} ${c.file || c.name}`
      + (c.renders ? `\n         ${c.renders}` : ''));
  }
  return out.join('\n') + '\n';
}

const HELP = `
Compact views over the site-intelligence indexes — every row still listed,
only the redundancy removed.

  node tools/query-index.js pages      --project <id> [--like <slug>] [--kind <k>] [--limit <n>]
  node tools/query-index.js components --project <id> [--min-usage <n>] [--grep <re>] [--limit <n>]

  --like <slug>     order pages by structural similarity to that page
  --kind <k>        service | contact | about | blog | faq | legal | location | general | …
  --min-usage <n>   components rendering on at least n pages
  --grep <re>       components whose name or description matches
  --limit <n>       show only the first n (the number hidden is reported)
  --json            machine-readable output
`;

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.error) { process.stderr.write(`  x  ${opts.error}\n${HELP}`); process.exit(2); }
  if (opts.help || !opts.what || !opts.project) { process.stdout.write(HELP); process.exit(opts.help ? 0 : 2); }

  let r;
  if (opts.what === 'pages') r = pages(opts);
  else if (opts.what === 'components') r = components(opts);
  else { process.stderr.write(`  x  unknown view "${opts.what}" — expected "pages" or "components".\n${HELP}`); process.exit(2); }

  if (r.error) { process.stderr.write(`  x  ${r.error}\n`); process.exit(1); }
  process.stdout.write(opts.json ? JSON.stringify(r, null, 2) + '\n'
    : (opts.what === 'pages' ? printPages(r) : printComponents(r)));
}

main();
