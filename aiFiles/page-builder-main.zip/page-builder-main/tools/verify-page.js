'use strict';

/**
 * Deterministic local validation — Phase 12, without an agent.
 *
 * Everything Phase 12 asks for is a fact, not a judgment: does the page
 * return 200, does it resolve to the expected template, do its assets load,
 * did PHP emit a notice, do the pages that already worked still work. An
 * agent answers those by pulling a whole rendered page into context and
 * reading it, which costs tens of thousands of tokens per attempt and can
 * still miss the one stylesheet that 404s.
 *
 * This script answers them exactly, and prints only what is wrong. The agent
 * reads the summary instead of the page. Nothing here interprets a design or
 * decides whether something looks right — that stays in Phase 13, where the
 * judgment actually is.
 *
 * Usage:
 *   node tools/verify-page.js --project <id> --page <slug> [--baseline <slug>...]
 *   node tools/verify-page.js --project <id> --url <absolute-url>
 *   ... --json      machine-readable output
 *
 * Exit code is 0 when every check passed, 1 when any failed, 2 on bad usage.
 * No dependencies, no shell, identical on macOS, Windows and Linux.
 */

const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const https = require('node:https');

const APP_ROOT = path.resolve(__dirname, '..');

/* ------------------------------------------------------------------- args */

function parseArgs(argv) {
  const out = { baseline: [], json: false, timeout: 15000 };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const val = () => argv[++i];
    if (a === '--project') out.project = val();
    else if (a === '--page') out.page = val();
    else if (a === '--url') out.url = val();
    else if (a === '--baseline') out.baseline.push(val());
    else if (a === '--timeout') out.timeout = Number(val()) || 15000;
    else if (a === '--json') out.json = true;
    else if (a === '--help' || a === '-h') out.help = true;
    else return { error: `unknown argument: ${a}` };
  }
  return out;
}

/* ------------------------------------------------------------------ fetch */

/** GET with redirect following. Never throws; a failure is a result. */
function fetchUrl(target, { timeout = 15000, method = 'GET', maxRedirects = 5, maxBytes = 4 * 1024 * 1024 } = {}) {
  return new Promise((resolve) => {
    let url;
    try { url = new URL(target); } catch { return resolve({ ok: false, error: 'unparseable URL', url: target }); }
    const mod = url.protocol === 'https:' ? https : http;

    const req = mod.request(url, { method, timeout, headers: { 'User-Agent': 'page-builder-verify/1' } }, (res) => {
      const status = res.statusCode || 0;
      const loc = res.headers.location;
      if (loc && status >= 300 && status < 400 && maxRedirects > 0) {
        res.resume();   // drain, or the socket is held open
        const next = new URL(loc, url).href;
        return fetchUrl(next, { timeout, method, maxRedirects: maxRedirects - 1, maxBytes }).then(resolve);
      }
      const chunks = [];
      let bytes = 0;
      res.on('data', (c) => {
        bytes += c.length;
        if (bytes <= maxBytes) chunks.push(c);
      });
      res.on('end', () => resolve({
        // Strictly 2xx. Redirects are followed above, so a 3xx arriving here
        // means the chain was never resolved — a redirect loop reported as a
        // pass is the one failure a verifier must never produce.
        ok: status >= 200 && status < 300,
        redirectUnresolved: status >= 300 && status < 400,
        status,
        bytes,
        contentType: res.headers['content-type'] || '',
        body: method === 'GET' ? Buffer.concat(chunks).toString('utf8') : '',
        url: url.href,
      }));
    });

    req.on('timeout', () => { req.destroy(); resolve({ ok: false, status: 0, error: `timed out after ${timeout}ms`, url: url.href }); });
    req.on('error', (err) => resolve({ ok: false, status: 0, error: err.code || err.message, url: url.href }));
    req.end();
  });
}

/** Run tasks with a small concurrency cap — a local stack is easy to swamp. */
async function pool(items, limit, fn) {
  const out = [];
  let i = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (i < items.length) {
      const idx = i++;
      out[idx] = await fn(items[idx], idx);
    }
  });
  await Promise.all(workers);
  return out;
}

/* ------------------------------------------------------------- extraction */

/**
 * Every asset the page asks the browser to load.
 *
 * Regex rather than a DOM: the only question is which URLs appear in src and
 * href attributes, and pulling in a parser to answer it would add the one
 * dependency this tool is designed not to have.
 */
function extractAssets(html, baseUrl) {
  const found = new Map();
  const add = (raw, kind) => {
    if (!raw) return;
    const v = raw.trim().replace(/&amp;/g, '&');
    if (!v || v.startsWith('data:') || v.startsWith('#') || v.startsWith('mailto:') || v.startsWith('javascript:')) return;
    let abs;
    try { abs = new URL(v, baseUrl).href; } catch { return; }
    if (!/^https?:/.test(abs)) return;
    if (!found.has(abs)) found.set(abs, kind);
  };

  for (const m of html.matchAll(/<script\b[^>]*\ssrc=["']([^"']+)["']/gi)) add(m[1], 'script');
  for (const m of html.matchAll(/<link\b[^>]*\shref=["']([^"']+)["'][^>]*>/gi)) {
    const tag = m[0];
    if (/rel=["']?(stylesheet|preload)/i.test(tag)) add(m[1], 'style');
  }
  for (const m of html.matchAll(/<img\b[^>]*\ssrc=["']([^"']+)["']/gi)) add(m[1], 'image');
  // srcset carries the responsive variants, which 404 just as easily.
  for (const m of html.matchAll(/\ssrcset=["']([^"']+)["']/gi)) {
    for (const part of m[1].split(',')) add(part.trim().split(/\s+/)[0], 'image');
  }
  return [...found].map(([url, kind]) => ({ url, kind }));
}

/** PHP's own diagnostics, as they appear in rendered output. */
const PHP_ERROR = /\b(Fatal error|Parse error|Warning|Notice|Deprecated|Recoverable fatal error)\b\s*:\s*(.{0,160}?)\s+in\s+(\/|[A-Za-z]:\\)[^\s<]{0,200}\s+on line\s+\d+/gi;

function findPhpErrors(html) {
  const out = [];
  for (const m of html.matchAll(PHP_ERROR)) {
    out.push(`${m[1]}: ${m[2].replace(/\s+/g, ' ').trim()}`);
    if (out.length >= 20) break;
  }
  return [...new Set(out)];
}

/** WordPress's own fatal-error page, which returns 500 with a styled body. */
function isWpErrorPage(html) {
  return /<title>WordPress\s*(&rsaquo;|›)\s*Error<\/title>/i.test(html)
    || /There has been a critical error on this website/i.test(html);
}

/* ------------------------------------------------------------ debug.log */

function readDebugLog(wpRoot, maxBytes = 64 * 1024) {
  const f = path.join(wpRoot, 'wp-content', 'debug.log');
  let st;
  try { st = fs.statSync(f); } catch { return null; }
  const start = Math.max(0, st.size - maxBytes);
  let text = '';
  try {
    const fd = fs.openSync(f, 'r');
    const buf = Buffer.alloc(st.size - start);
    fs.readSync(fd, buf, 0, buf.length, start);
    fs.closeSync(fd);
    text = buf.toString('utf8');
  } catch { return null; }

  const lines = text.split('\n').filter((l) => /PHP (Fatal|Parse|Warning|Notice|Deprecated)/i.test(l));
  return {
    file: f,
    sizeBytes: st.size,
    modifiedMs: st.mtimeMs,
    recent: lines.slice(-12),
    count: lines.length,
  };
}

/* ----------------------------------------------------------------- checks */

function check(id, label, status, detail) {
  return { id, label, status, detail };
}

async function verify(opts) {
  const intelDir = path.join(APP_ROOT, '.claude', 'tmp', opts.project, 'site-intelligence');
  const archFile = path.join(intelDir, 'architecture.json');
  if (!fs.existsSync(archFile)) {
    return { ok: false, checks: [check('project', 'Project', 'fail', `No site intelligence at ${archFile}`)] };
  }
  const arch = JSON.parse(fs.readFileSync(archFile, 'utf8'));
  const wpRoot = (arch.paths && arch.paths.wpRoot) || null;
  const siteUrl = (arch.wordpress && (arch.wordpress.siteUrl || arch.wordpress.home)) || null;

  if (!opts.url && !siteUrl) {
    return { ok: false, checks: [check('site', 'Site URL', 'fail', 'architecture.json records no siteUrl — pass --url instead.')] };
  }

  const base = siteUrl && siteUrl.endsWith('/') ? siteUrl : `${siteUrl || ''}/`;
  // Encode each segment: a slug with a space produced an invalid URL, and one
  // with `..` silently pointed the check somewhere else entirely.
  const encodeSlug = (slug) => String(slug)
    .split('/')
    // Drop `.` and `..`: they survive encoding untouched, and a slug carrying
    // them would quietly verify a different page and report it as a pass.
    .filter((seg) => seg && seg !== '.' && seg !== '..')
    .map(encodeURIComponent)
    .join('/');
  const pageUrl = opts.url || `${base}${encodeSlug(opts.page)}/`;

  const checks = [];
  const detail = { pageUrl, wpRoot, siteUrl };

  /* 1. does the page load at all */
  const res = await fetchUrl(pageUrl, { timeout: opts.timeout });
  if (!res.ok) {
    const why = res.redirectUnresolved
      ? 'redirects too many times to resolve (loop, or more than 5 hops)'
      : res.error || 'unexpected status';
    checks.push(check('load', 'Page loads', 'fail',
      `${pageUrl} -> ${res.status || 'no response'} (${why})`));
  } else {
    checks.push(check('load', 'Page loads', 'pass', `HTTP ${res.status}, ${(res.bytes / 1024).toFixed(1)} KB`));
  }

  const html = res.body || '';
  detail.status = res.status;
  detail.bytes = res.bytes || 0;

  /* 2. WordPress's own error page, which can arrive with a 200 as easily as a 500 */
  if (html && isWpErrorPage(html)) {
    checks.push(check('wp-error', 'WordPress error page', 'fail',
      'The response is WordPress\'s critical-error page, not the page template.'));
  }

  /* 3. PHP diagnostics in the rendered output */
  const phpErrors = html ? findPhpErrors(html) : [];
  checks.push(phpErrors.length
    ? check('php', 'PHP output clean', 'fail', `${phpErrors.length} diagnostic(s): ${phpErrors.slice(0, 5).join(' | ')}`)
    : check('php', 'PHP output clean', 'pass', 'No PHP notices, warnings or fatals in the rendered HTML.'));
  detail.phpErrors = phpErrors;

  /* 4. every asset the page references */
  if (html) {
    const assets = extractAssets(html, pageUrl);
    const origin = new URL(pageUrl).origin;
    const local = assets.filter((a) => a.url.startsWith(origin));
    const external = assets.length - local.length;

    const results = await pool(local, 6, async (a) => {
      let r = await fetchUrl(a.url, { timeout: opts.timeout, method: 'HEAD', maxBytes: 1 });
      // Some servers refuse HEAD; a GET is the fallback rather than a verdict.
      if (!r.ok && (r.status === 405 || r.status === 501 || r.status === 0)) {
        r = await fetchUrl(a.url, { timeout: opts.timeout, maxBytes: 64 * 1024 });
      }
      return { ...a, status: r.status, ok: r.ok, error: r.error || null };
    });

    const broken = results.filter((r) => !r.ok);
    checks.push(broken.length
      ? check('assets', 'Assets load', 'fail',
          `${broken.length} of ${local.length} local asset(s) failed: `
          + broken.slice(0, 8).map((b) => `${b.status || b.error} ${b.kind} ${b.url.replace(origin, '')}`).join(' | '))
      : check('assets', 'Assets load', 'pass',
          `${local.length} local asset(s) all load${external ? `, ${external} external not checked` : ''}.`));
    detail.assets = { checked: local.length, external, broken };
  }

  /* 5. the pages that already worked must still work */
  const baselines = [...new Set(['', ...opts.baseline])];
  const baseResults = await pool(baselines, 4, async (slug) => {
    const u = slug ? `${base}${encodeSlug(slug)}/` : base;
    const r = await fetchUrl(u, { timeout: opts.timeout });
    return { slug: slug || '(home)', url: u, status: r.status, ok: r.ok && !isWpErrorPage(r.body || ''), error: r.error || null };
  });
  const brokeBaseline = baseResults.filter((b) => !b.ok);
  checks.push(brokeBaseline.length
    ? check('regression', 'Existing pages still work', 'fail',
        brokeBaseline.map((b) => `${b.slug} -> ${b.status || b.error}`).join(' | '))
    : check('regression', 'Existing pages still work', 'pass',
        `${baseResults.length} checked: ${baseResults.map((b) => b.slug).join(', ')}`));
  detail.baselines = baseResults;

  /* 6. debug.log, which catches what never reaches the browser */
  if (wpRoot) {
    const log = readDebugLog(wpRoot);
    if (!log) {
      checks.push(check('debug-log', 'debug.log', 'pass', 'No wp-content/debug.log (WP_DEBUG_LOG off, or nothing logged).'));
    } else {
      const fresh = Date.now() - log.modifiedMs < 10 * 60 * 1000;
      checks.push(log.count && fresh
        ? check('debug-log', 'debug.log', 'fail',
            `${log.count} PHP line(s), written ${Math.round((Date.now() - log.modifiedMs) / 1000)}s ago: `
            + log.recent.slice(-3).map((l) => l.slice(0, 160)).join(' | '))
        : check('debug-log', 'debug.log', log.count ? 'warn' : 'pass',
            log.count
              ? `${log.count} PHP line(s), but nothing in the last 10 minutes — probably older than this build.`
              : 'Present and free of PHP diagnostics.'));
      detail.debugLog = { count: log.count, modifiedMs: log.modifiedMs };
    }
  }

  return { ok: !checks.some((c) => c.status === 'fail'), checks, detail };
}

/* ------------------------------------------------------------------- main */

const HELP = `
Deterministic Phase 12 validation — no agent, no tokens.

  node tools/verify-page.js --project <id> --page <slug> [options]

  --project <id>       project id under .claude/tmp/
  --page <slug>        the page to validate
  --url <url>          validate this absolute URL instead
  --baseline <slug>    an existing page that must not break (repeatable)
  --timeout <ms>       per-request timeout (default 15000)
  --json               machine-readable output

Exit 0 = every check passed, 1 = something failed.
`;

async function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.error) { process.stderr.write(`  x  ${opts.error}\n${HELP}`); process.exit(2); }
  if (opts.help || !opts.project || (!opts.page && !opts.url)) { process.stdout.write(HELP); process.exit(opts.help ? 0 : 2); }

  const result = await verify(opts);

  if (opts.json) {
    process.stdout.write(JSON.stringify(result, null, 2) + '\n');
  } else {
    const MARK = { pass: 'ok  ', warn: 'warn', fail: 'FAIL' };
    process.stdout.write(`\n  Verifying ${result.detail ? result.detail.pageUrl : opts.page}\n\n`);
    for (const c of result.checks) {
      process.stdout.write(`  ${MARK[c.status]}  ${c.label}\n         ${c.detail}\n`);
    }
    process.stdout.write(`\n  ${result.ok ? 'All checks passed.' : 'One or more checks FAILED.'}\n\n`);
  }
  process.exit(result.ok ? 0 : 1);
}

main().catch((err) => { process.stderr.write(`  x  ${err && err.stack || err}\n`); process.exit(2); });
