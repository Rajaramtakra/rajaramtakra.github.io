#!/bin/bash
#
# macOS — double-click this file in Finder to start the Page Builder launcher
# and open it in your browser.
#
# This wrapper only has one job: find Node. All the real logic is in
# launcher/start.js, which is shared with Windows and Linux.

set -u
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Gatekeeper marks every file that arrives from a browser download, AirDrop or
# a cloud-sync client with com.apple.quarantine, and refuses to run a
# quarantined script from Finder at all. A quarantined copy of this file cannot
# clear its own flag — it never gets to run — so that first launch has to come
# from Terminal (see "READ ME FIRST (macOS).txt"). What this block does is stop
# the problem from coming back: once the script runs from anywhere, it clears
# the flag from the whole install, so later double-clicks work and a folder
# that syncs itself back into a quarantined state heals on the next run.
# `xattr -dr` is a no-op on a file that carries no flag and exits non-zero on a
# read-only volume, so it is run unconditionally and its result ignored. It is
# scoped to the three paths the launcher actually executes rather than the whole
# folder, which keeps it off .claude/tmp and any WordPress install underneath.
if command -v xattr >/dev/null 2>&1; then
  for target in "${DIR}/Start Page Builder.command" "${DIR}/launcher" "${DIR}/tools"; do
    [ -e "${target}" ] && xattr -dr com.apple.quarantine "${target}" >/dev/null 2>&1
  done
  true
fi

# Zip and cloud-sync round trips also drop the executable bit, which Finder
# reports as an unhelpful "the file is not executable" rather than a fixable
# permission problem.
[ -x "${DIR}/Start Page Builder.command" ] || chmod +x "${DIR}/Start Page Builder.command" 2>/dev/null || true

# Finder launches scripts with a minimal PATH that excludes /usr/local/bin
# and Homebrew, so Node has to be found deliberately rather than inherited.
export PATH="/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin:${PATH}"
if [ -s "${HOME}/.nvm/nvm.sh" ]; then
  # shellcheck disable=SC1091
  . "${HOME}/.nvm/nvm.sh" >/dev/null 2>&1 || true
fi

NODE="$(command -v node || true)"
if [ -z "${NODE}" ]; then
  echo ""
  echo "  x  Node.js was not found."
  echo ""
  echo "     Install it from https://nodejs.org, then double-click this file again."
  echo ""
  exit 1
fi

exec "${NODE}" "${DIR}/launcher/start.js"
