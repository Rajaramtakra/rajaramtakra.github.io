'use strict';

/**
 * Cross-platform starter for the Page Builder launcher.
 *
 * Starts the server if it is not already running, waits until it actually
 * accepts connections, then opens the page in the default browser.
 *
 * All the logic lives here rather than in the shell wrappers, so macOS,
 * Windows, and Linux run identical code and only the "find Node" step
 * differs per platform.
 *
 * Run:  node launcher/start.js
 */

const http = require('node:http');
const path = require('node:path');
const fs = require('node:fs');
const { spawn } = require('node:child_process');
const { buildId } = require('./lib/build-id');

const PORT = Number(process.env.PORT) || 4599;
const HOST = '127.0.0.1';
const URL_ = `http://${HOST}:${PORT}`;
const APP_ID = 'page-builder-launcher';

const SERVER = path.join(__dirname, 'server.js');
const LOG = path.join(__dirname, 'server.log');

const say = (s) => process.stdout.write(s + '\n');

/**
 * Ask the port who it is.
 *
 * Returns `{ state, pid, build }` where state is:
 *   'ours'    — our launcher is already running
 *   'free'    — nothing is listening
 *   'foreign' — something else holds the port
 *
 * `build` identifies the code that server actually loaded. A server started
 * before an edit keeps serving its old routes indefinitely — the page is read
 * from disk per request and looks current, so the mismatch shows up as a new
 * button getting a 404 rather than as anything obviously stale.
 */
function probe(timeoutMs = 1500) {
  return new Promise((resolve) => {
    const req = http.get(`${URL_}/api/health`, { timeout: timeoutMs }, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (d) => { body += d; if (body.length > 4096) req.destroy(); });
      res.on('end', () => {
        try {
          const h = JSON.parse(body);
          if (h.app !== APP_ID) return resolve({ state: 'foreign' });
          // A server predating this check reports no build at all, which is
          // itself proof that it is older than the code on disk.
          resolve({ state: 'ours', pid: h.pid || null, build: h.build || null });
        } catch {
          resolve({ state: 'foreign' });
        }
      });
    });
    req.on('timeout', () => { req.destroy(); resolve({ state: 'foreign' }); });
    req.on('error', (err) => {
      resolve({ state: err.code === 'ECONNREFUSED' || err.code === 'ECONNRESET' ? 'free' : 'foreign' });
    });
  });
}

/**
 * Stop a server we own and wait for the port to come free.
 *
 * `process.kill` is the portable way to do this — no `kill`/`taskkill` branch
 * and no shell. On POSIX SIGTERM lets the server close its listener cleanly;
 * on Windows it terminates the process outright, since signals do not exist
 * there. Both release the port, which is the only thing this waits on. The
 * SIGKILL escalation covers a process wedged past a clean shutdown.
 */
async function stopServer(pid) {
  if (!pid) return false;
  try {
    process.kill(pid, 'SIGTERM');
  } catch (err) {
    // ESRCH means it is already gone, which is the outcome we wanted.
    if (err.code !== 'ESRCH') return false;
  }
  for (let i = 0; i < 30; i++) {
    await sleep(100);
    if ((await probe(700)).state === 'free') return true;
  }
  try { process.kill(pid, 'SIGKILL'); } catch { /* already gone */ }
  for (let i = 0; i < 20; i++) {
    await sleep(100);
    if ((await probe(700)).state === 'free') return true;
  }
  return false;
}

function openBrowser(url) {
  const p = process.platform;
  const [cmd, args] =
    p === 'darwin' ? ['open', [url]]
    : p === 'win32' ? ['cmd', ['/c', 'start', '', url]]
    : ['xdg-open', [url]];
  try {
    spawn(cmd, args, { detached: true, stdio: 'ignore', windowsHide: true }).unref();
  } catch {
    say(`  (could not open a browser automatically — visit ${url})`);
  }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function main() {
  say('');
  say('  Page Builder launcher');
  say('  ---------------------');
  say('');

  if (!fs.existsSync(SERVER)) {
    say(`  x  Could not find ${SERVER}`);
    say('     Keep this script inside the Page Builder folder.');
    say('');
    process.exit(1);
  }

  const mine = buildId();
  let health = await probe();
  let state = health.state;

  if (state === 'ours' && health.build === mine) {
    say(`  Already running at ${URL_}`);
    openBrowser(URL_);
    say('');
    say('  You can close this window.');
    say('');
    return;
  }

  if (state === 'ours') {
    // Same launcher, older code. Reusing it would serve a current page from a
    // stale server, which fails in the confusing direction: the UI shows a
    // feature the running process has no route for.
    say('  The launcher already running is out of date. Restarting it...');
    if (!await stopServer(health.pid)) {
      say('');
      say(`  x  Could not stop the old launcher (pid ${health.pid || 'unknown'}).`);
      say('');
      say('     Stop it yourself, then run this again:');
      say(process.platform === 'win32'
        ? `       taskkill /PID ${health.pid} /F`
        : `       kill ${health.pid}`);
      say('');
      process.exit(1);
    }
    state = 'free';
  }

  if (state === 'foreign') {
    say(`  x  Port ${PORT} is in use by another program.`);
    say('');
    say('     Free it, or start on a different port:');
    say(process.platform === 'win32'
      ? `       set PORT=4600 && node "${__filename}"`
      : `       PORT=4600 node "${__filename}"`);
    say('     (then open http://127.0.0.1:4600)');
    say('');
    process.exit(1);
  }

  say(`  Starting server (node ${process.version})...`);

  // Detach so the server outlives this script and the terminal window.
  const out = fs.openSync(LOG, 'a');
  const child = spawn(process.execPath, [SERVER], {
    detached: true,
    stdio: ['ignore', out, out],
    windowsHide: true,
    env: { ...process.env, PORT: String(PORT) },
  });
  child.unref();

  for (let i = 0; i < 40; i++) {
    await sleep(250);
    if ((await probe(1000)).state === 'ours') {
      say(`  ok  Running at ${URL_}  (pid ${child.pid})`);
      openBrowser(URL_);
      say('');
      say('  Leave it running in the background. To stop it:');
      say(process.platform === 'win32'
        ? `    taskkill /PID ${child.pid} /F`
        : `    kill ${child.pid}`);
      say('');
      say('  You can close this window.');
      say('');
      return;
    }
  }

  say('  x  Server failed to start within 10 seconds. Last log lines:');
  say('');
  try {
    const lines = fs.readFileSync(LOG, 'utf8').trim().split('\n').slice(-20);
    for (const l of lines) say('     ' + l);
  } catch {
    say('     (no log written)');
  }
  say('');
  process.exit(1);
}

main().catch((err) => {
  say(`  x  ${err && err.message ? err.message : err}`);
  process.exit(1);
});
