'use strict';

/**
 * Page Builder — launcher server.
 *
 * Local-only. Binds 127.0.0.1, has no dependencies, and makes no outbound
 * network calls.
 *
 * The server does the work that would otherwise be paid for in tokens on
 * every single run:
 *
 *   - keeps a registry of many projects, each with isolated intelligence
 *   - resolves the WordPress root, the local stack, and DB reachability
 *   - extracts content from the local database, or from an uploaded WXR
 *   - scans the source tree deterministically
 *   - writes a persistent site-intelligence directory per project
 *
 * It writes only inside `.claude/tmp/` in the Page Builder folder. It never
 * writes anything into the user's WordPress project, and it never stores a
 * database credential.
 *
 * Run:  node launcher/server.js      (then open http://127.0.0.1:4599)
 */

const http = require('node:http');
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');

const { ensureDirSync, readJsonSafe, statOr, nowIso, slugify } = require('./lib/util');
const paths = require('./lib/paths');
const validate = require('./lib/validate');
const registry = require('./lib/registry');
const intelligence = require('./lib/intelligence');
const indexer = require('./lib/indexer');
const promptBuilder = require('./lib/prompt');
const sessions = require('./lib/sessions');
const migrate = require('./lib/migrate');
const wxr = require('./lib/wxr');
const image = require('./lib/image');
const wpDetect = require('./lib/wp-detect');
const { buildId } = require('./lib/build-id');
const progress = require('./lib/progress');
const preflight = require('./lib/preflight');
const usage = require('./lib/usage');
const db = require('./lib/db');

const HOST = '127.0.0.1';
const PORT = Number(process.env.PORT) || 4599;

/** Identifies this server to the start script, so it can tell "already
 *  running" from "port taken by something else" without needing lsof. */
const APP_ID = 'page-builder-launcher';
const APP_VERSION = 1;
// Computed once at startup, so it describes the code this process actually
// loaded — not whatever is on disk by the time someone asks.
const BUILD_ID = buildId();

const check = validate.check;

/* ------------------------------------------------------------------ routes */

/** GET /api/projects — the Existing Project dropdown. */
function listProjects() {
  const { projects, repaired, problems } = registry.load();
  if (repaired) registry.save(projects, problems);

  return {
    projects: projects.map((p) => ({
      id: p.id,
      name: p.name,
      projectPath: p.projectPath,
      wpRoot: p.wpRoot,
      platform: p.platform || 'WordPress',
      builder: p.builder,
      theme: p.themeName || p.theme,
      themeSlug: p.theme,
      childTheme: !!p.childTheme,
      pagesIndexed: p.pagesIndexed || 0,
      lastIndexedAt: p.lastIndexedAt,
      lastUsedAt: p.lastUsedAt,
      contentSource: p.contentSource || null,
      intelligenceVersion: p.intelligenceVersion,
      migratedFromLegacy: !!p.migratedFromLegacy,
      needsRefresh: !!p.needsRefresh,
      pathExists: p.pathExists,
      healthy: p.healthy,
    })),
    problems,
    legacy: migrate.inspect().filter((l) => !l.alreadyImported).length,
  };
}

/**
 * GET /api/progress/:projectId — how far along each page build is.
 *
 * Reads the pipeline's own `progress.json` where it exists and falls back to
 * what the notes directory proves, then folds a finished run back into the
 * page history so the two views cannot disagree.
 */
function pageProgress(projectId) {
  if (!paths.isSafeId(projectId)) return { error: 'Unusable project id.' };
  const project = registry.get(projectId);
  if (!project) return { error: `No project with id \`${projectId}\`.` };

  const history = registry.pageHistory(projectId);

  // Walked oldest first, because a batch has to be costed in build order: the
  // pages of one hand-off run back to back in a single session, and each one's
  // window starts where the page before it stopped. Reversed for display at
  // the end, which is where "newest first" belongs.
  let batch = null;   // { id, until } — the page before this one, in this batch

  const pages = (history.pages || []).map((entry) => {
    const p = progress.read({ projectId, slug: entry.slug, historyEntry: entry });
    // A run the pipeline reported as finished should stop reading as "started"
    // in the history for ever after.
    if (p.known && (p.state === 'done' || p.state === 'failed')
        && !['complete', 'completed', 'failed'].includes(entry.status)) {
      registry.advanceStatus(projectId, entry.slug, p.state === 'done' ? 'complete' : 'failed');
      entry.status = p.state === 'done' ? 'complete' : 'failed';
    }
    // What the run cost, read out of Claude Code's own transcripts. A build
    // that has not reached the API yet reports `known: false` and the UI
    // simply omits the report rather than showing zeroes.
    const cost = usage.forPage({
      projectPaths: [project.projectPath, project.wpRoot],
      entry,
      progress: p.known ? p : null,
      notBefore: batch && entry.batchId && batch.id === entry.batchId ? batch.until : null,
    });

    batch = entry.batchId
      ? { id: entry.batchId, until: (cost.window && cost.window.to) || null }
      : null;

    return {
      pageName: entry.pageName,
      slug: entry.slug,
      status: entry.status,
      attempts: entry.attempts || 1,
      createdAt: entry.createdAt,
      referenceType: entry.referenceType || null,
      // So the UI can say a page was one of several handed over together.
      batchId: entry.batchId || null,
      progress: p,
      usage: cost,
    };
  }).reverse();   // newest first, for display

  return { ok: true, projectId, total: progress.TOTAL, phases: progress.PHASES, pages };
}

/** GET /api/projects/:id — the cached detail card, plus a staleness verdict. */
function projectDetail(id) {
  const project = registry.get(id);
  if (!project) return { error: `No project with id \`${id}\`.` };

  const intel = intelligence.summary(id);
  const staleness = project.wpRoot
    ? intelligence.checkStaleness({ id, wpRoot: project.wpRoot })
    : { known: false, stale: true, reasons: ['no WordPress root recorded'] };
  const history = registry.pageHistory(id);

  return {
    project: {
      ...project,
      intelDir: intel.intelDir,
    },
    intelligence: intel,
    staleness,
    history: {
      count: (history.pages || []).length,
      pages: (history.pages || []).slice(-8).reverse(),
    },
  };
}

/** POST /api/inspect — live feedback while the New Project form is filled in. */
async function inspect(body) {
  // Either a typed path (New Project) or an already-registered project, so
  // "Test connection" works the same in both modes.
  const known = body.projectId ? registry.get(String(body.projectId)) : null;
  const projectPath = known
    ? (known.wpRoot || known.projectPath)
    : String(body.projectPath || '').trim();
  const pathCheck = validate.validateProjectPath(projectPath);

  if (!pathCheck.ok) return { ok: false, checks: [pathCheck.c] };

  const ov = validate.validateDbOverride(body.dbOverride);
  if (!ov.ok) return { ok: false, checks: [pathCheck.c, ov.c] };

  const result = await indexer.inspectPath({
    projectPath: pathCheck.value, probeDatabase: true, dbOverride: ov.value,
  });
  const checks = [pathCheck.c];
  if (ov.c) checks.push(ov.c);

  if (!result.ok) {
    return { ok: false, checks: [...checks, check('inspect', 'Inspection', 'fail', `Could not inspect this path (${result.reason}).`)] };
  }

  checks.push(check('stack', 'Local environment',
    result.stack === 'unknown' ? 'warn' : 'pass',
    result.stack === 'unknown'
      ? `WordPress ${result.wpVersion || '(version unknown)'} — the local stack could not be identified. That only affects how the site is loaded for visual QA.`
      : `WordPress ${result.wpVersion || '(version unknown)'} on ${result.stack}.`));

  checks.push(result.database.available
    ? check('db', 'WordPress content — automatic', 'pass',
        `The local database is reachable (${result.database.via}). Content will be extracted automatically — no XML export needed.`)
    : check('db', 'WordPress content — needs an export', 'warn',
        `The local database could not be read: ${result.database.reason}. `
        + 'Set the connection yourself under "Where is the database?", upload a WXR/XML export instead, or skip content indexing.'));

  if (result.knownProject) {
    checks.push(check('known', 'Already registered', 'warn',
      `This path is already the project "${result.knownProject.name}". Use Existing Project to reuse its cached intelligence instead of re-indexing.`));
  }

  return {
    ok: true,
    checks,
    inspection: {
      wpRoot: result.wpRoot,
      wpVersion: result.wpVersion,
      stack: result.stack,
      fullInstall: result.fullInstall,
      databaseAvailable: result.database.available,
      databaseVia: result.database.via || null,
      databaseReason: result.database.reason || null,
      // What was actually tried, so a failure is diagnosable in the UI rather
      // than reduced to a single sentence.
      databaseAttempts: (result.database.attempts || []).slice(0, 12),
      dbOverride: ov.value,
      themes: result.themes,
      knownProject: result.knownProject,
      recommendedContentMode: result.database.available ? 'auto' : 'wxr',
    },
  };
}

/**
 * POST /api/db-detect — "where is my database?"
 *
 * Answers without connecting as anyone: which stack, what `wp-config.php`
 * asks for, which candidate sockets and ports actually have a MySQL server
 * behind them (identified from the server's own handshake, no credentials),
 * and which client binaries exist. The UI turns each live server into a
 * one-click connection override.
 */
async function dbDetect(body) {
  // Either an already-registered project, or a raw path being typed in.
  const project = body.projectId ? registry.get(String(body.projectId)) : null;
  const rawPath = project ? (project.wpRoot || project.projectPath) : String(body.projectPath || '').trim();
  if (!rawPath) return { ok: false, error: 'Give a project path first.' };

  const resolved = wpDetect.resolveWpRoot(rawPath);
  if (!resolved.ok) return { ok: false, error: `No WordPress install found under ${rawPath}.` };

  const wpRoot = resolved.wpRoot;
  const cfg = wpDetect.readWpConfig(wpRoot);
  const stack = wpDetect.detectLocalStack(wpRoot);
  const found = await db.detect({ wpRoot, cfg, stack: stack.stack });

  return {
    ok: true,
    wpRoot,
    stack: found.stack,
    stackSignals: stack.signals,
    wpConfig: found.wpConfig,
    servers: found.servers.map((srv) => ({
      label: srv.label,
      target: srv.target,
      alive: !!srv.alive,
      isMysql: !!(srv.alive && !srv.notMysql),
      serverVersion: srv.serverVersion || null,
      reason: srv.reason || null,
    })),
    clients: found.clients,
    current: project ? (project.dbOverride || null) : null,
  };
}

/**
 * POST /api/validate — the Start Building action, for both modes.
 *
 * The payload carries a `pages` array — one entry per page to build, each with
 * its own reference, live URL and notes. A design hand-off is normally a set of
 * pages, and everything expensive about a run (resolving the WordPress root,
 * reading the content, resolving the architecture from the indexes) is
 * identical for all of them, so they are validated, recorded and prompted for
 * together.
 *
 * The older flat shape ({ pageName, referenceType, figmaLink, … }) is still
 * accepted and read as a batch of one, so a scripted post or a saved bookmark
 * keeps working. So does a bare payload with no `mode`, which is treated as a
 * new/existing project by path.
 */
async function handleStart(body) {
  const mode = body.mode === 'existing' ? 'existing' : 'new';
  const checks = [];

  const inputs = pageInputs(body);
  // The batch as a whole first — a duplicate page name is a property of the
  // set, not of either page in it.
  const set = validate.validatePageSet(inputs.map((p) => p.pageName));
  const pages = inputs.map((input, i) => preparePage(input, { mode, projectId: body.projectId }, i, inputs.length));
  const pagesOk = set.ok && pages.every((p) => p.ok);
  // A batch rejected as a batch — too many pages, two pages with one slug —
  // is answered by one line, and twenty-six rows of "Reference verified" below
  // it would bury the only one worth reading. What still earns a row is a page
  // that is independently broken.
  const pageChecks = set.ok
    ? pages.flatMap((p) => p.checks)
    : pages.filter((p) => !p.ok).flatMap((p) => p.checks);

  /* ---------------------------------------------------- existing project */
  if (mode === 'existing') {
    const project = registry.get(String(body.projectId || ''));
    if (!project) {
      return {
        ok: false,
        checks: [check('project', 'Project', 'fail',
          body.projectId ? `No project with id \`${body.projectId}\`. It may have been removed from .claude/tmp/.` : 'Select a project.')],
      };
    }
    if (!project.pathExists) {
      return {
        ok: false,
        checks: [check('project', 'Project path missing', 'fail',
          `${project.name} points at ${project.projectPath}, which no longer exists. Move the site back, or register it again as a new project.`)],
      };
    }

    const intel = intelligence.summary(project.id);
    if (!intel.hasIntelligence) {
      checks.push(check('intel', 'No cached intelligence', 'warn',
        'This project has no site intelligence yet. Use Refresh Site Intelligence first, or the agent will have to discover everything itself.'));
    }

    checks.push(check('project', 'Project', 'pass',
      `${project.name} — ${project.wpRoot}`));

    if (!pagesOk) {
      return { ok: false, checks: [...checks, set.c, ...pageChecks].filter(Boolean) };
    }
    if (set.c) checks.push(set.c);
    checks.push(...pageChecks);

    const staleness = intelligence.checkStaleness({ id: project.id, wpRoot: project.wpRoot });
    checks.push(intel.hasIntelligence
      ? check('intel', staleness.stale ? 'Cached intelligence — stale' : 'Cached intelligence — fresh',
          staleness.stale ? 'warn' : 'pass',
          staleness.stale
            ? `Indexed ${fmtDate(intel.lastScan)}; ${staleness.reasons.join('; ')}. Start Building will not re-scan — use Refresh Site Intelligence if that matters for this page.`
            : `Indexed ${fmtDate(intel.lastScan)} · ${intel.pagesIndexed} pages · content from ${intel.contentSource === 'db' ? 'the local database' : 'a WXR export'} · ${intel.componentsInspected}/${intel.components} components described. Reused as-is.`)
      : check('intel', 'Cached intelligence', 'warn', 'None — the agent will index the project on this run.'));

    checks.push(sessions.describe(await sessions.find(project.wpRoot), check));

    // Read history before recording these pages, so the prompt describes prior
    // work rather than listing the pages being started as already built.
    const priorHistory = registry.pageHistory(project.id);
    const built = commitPages(pages, project, checks);
    registry.update(project.id, { lastUsedAt: nowIso() });

    return {
      ok: true,
      checks,
      projectId: project.id,
      prompt: promptBuilder.build({
        project: { ...project, intelDir: intel.intelDir },
        pages: built,
        intel,
        staleness,
        history: priorHistory,
      }),
      pageRecords: built.map((b) => b.record),
      // The first record, for a caller written before a run could carry more
      // than one page.
      pageRecord: built[0].record,
    };
  }

  /* --------------------------------------------------------- new project */
  // A bare payload has no project name. Deriving one from the directory
  // keeps old prompts and bookmarks working rather than failing validation on
  // a field that did not exist when they were saved.
  const derivedName = body.projectName
    || (body.projectPath ? path.basename(String(body.projectPath).replace(/[\\/]+$/, '')) : '');
  const name = validate.validateProjectName(derivedName);
  const projectPath = validate.validateProjectPath(body.projectPath);
  const contentMode = validate.validateContentMode(body.contentMode);
  const dbOv = validate.validateDbOverride(body.dbOverride);
  if (!dbOv.ok) return { ok: false, checks: [dbOv.c], prompt: null };

  const inputsOk = name.ok && projectPath.ok && pagesOk && contentMode.ok;
  checks.push(check('inputs', 'Validating inputs', inputsOk ? 'pass' : 'fail',
    inputsOk ? 'All fields present and well-formed.' : 'One or more fields need attention.'));
  checks.push(name.c, projectPath.c);
  if (set.c) checks.push(set.c);
  checks.push(...pageChecks);
  if (!contentMode.ok) checks.push(contentMode.c);

  let wxrPath = null;
  let wxrModel = null;
  if (contentMode.ok && contentMode.value === 'wxr') {
    const staged = body.wxrToken ? resolveStagedUpload(body.wxrToken) : null;
    wxrModel = stagedModel(staged);
    if (wxrModel) {
      // Already parsed at upload; do not read the export a second time.
      wxrPath = staged;
      const s = wxrModel.stats;
      checks.push(check('wxr', 'WXR export', 'pass',
        `WXR ${s.wxrVersion}, ${s.items} items, ${s.posts} content items — using the model parsed at upload.`));
    } else {
      const wxrCheck = await validate.validateWxrFile(staged || body.wxrPath);
      checks.push(wxrCheck.c);
      if (!wxrCheck.ok) return { ok: false, checks };
      wxrPath = wxrCheck.value;
    }
  }

  if (!inputsOk) return { ok: false, checks, prompt: null };

  /* ---- register and index --------------------------------------------- */
  const { project, created } = registry.upsert({
    name: name.value,
    projectPath: projectPath.providedPath || projectPath.value,
    wpRoot: projectPath.value,
    // Stored so `Refresh` reconnects without asking again. Credential-free by
    // construction — the validator accepts no user or password. Only written
    // when one was actually given: this path also reuses an already-registered
    // project, and blank fields there mean "unchanged", not "forget it".
    extra: dbOv.value ? { dbOverride: dbOv.value } : {},
  });
  if (dbOv.c) checks.push(dbOv.c);

  const renamed = !created && project.name !== name.value;
  checks.push(check('register', created ? 'Project registered' : 'Existing project reused', 'pass',
    created
      ? `Created .claude/tmp/${project.id}/ — this project's intelligence is isolated from every other project.`
      : `This WordPress root is already registered as "${project.name}", so its intelligence directory is being reused rather than a second one created.`
        + (renamed ? ` The name "${name.value}" was not applied — an existing project keeps its own name.` : '')));

  const result = await indexer.indexProject({
    project,
    contentMode: contentMode.value,
    wxrFile: wxrPath,
    wxrRaw: wxrModel,
    // undefined, not null, so a project that already has a stored connection
    // keeps using it when these fields were left blank.
    dbOverride: dbOv.value || undefined,
  });

  if (!result.ok) {
    checks.push(check('index', 'Indexing failed', 'fail', result.error));
    return { ok: false, checks, projectId: project.id };
  }

  checks.push(describeContentSource(result, contentMode.value));
  checks.push(check('index', 'Site intelligence built', 'pass',
    `${result.summary.pagesIndexed} pages, ${result.summary.components} candidate components, `
    + `theme ${result.summary.theme || 'UNKNOWN'}${result.summary.childTheme ? ' (child)' : ''}, `
    + `builder ${result.summary.builder || 'UNKNOWN'} — written in ${(result.ms / 1000).toFixed(1)}s to .claude/tmp/${project.id}/site-intelligence/`));

  for (const note of result.notes.slice(0, 6)) {
    checks.push(check('note', 'Note', 'warn', note));
  }

  // The export now lives inside the project, so the staged copy (and its
  // parsed model) are just a duplicate of a possibly very large file.
  if (body.wxrToken) releaseStagedUpload(body.wxrToken);

  checks.push(sessions.describe(await sessions.find(result.project.wpRoot), check));

  const priorHistory = registry.pageHistory(project.id);
  const built = commitPages(pages, project, checks);

  return {
    ok: true,
    checks,
    projectId: project.id,
    prompt: promptBuilder.build({
      project: { ...result.project, intelDir: result.summary.intelDir },
      pages: built,
      intel: result.summary,
      staleness: { known: true, stale: false, reasons: [], ageDays: 0 },
      history: priorHistory,
    }),
    pageRecords: built.map((b) => b.record),
    pageRecord: built[0].record,
  };
}

/**
 * The pages this run is being asked to build.
 *
 * One reference is one page: a Figma link, an HTML export, or a set of
 * screenshots describes a single page, which is what makes a batch
 * expressible at all. The flat fields are that same payload with the array
 * flattened away, so both shapes converge here and nothing downstream has to
 * know which one arrived.
 */
function pageInputs(body) {
  // An explicitly empty `pages` is an empty batch, not an absent one. Falling
  // back to the flat fields there would answer "Page name is required" over a
  // payload that named no page at all.
  if (Array.isArray(body.pages)) return body.pages.filter((p) => p && typeof p === 'object');
  return [{
    pageName: body.pageName,
    referenceType: body.referenceType,
    figmaLink: body.figmaLink,
    htmlPath: body.htmlPath,
    screenshotTokens: body.screenshotTokens,
    screenshotPath: body.screenshotPath,
    liveUrl: body.liveUrl,
    notes: body.notes,
  }];
}

/**
 * Validate one page of the batch.
 *
 * Every page carries its own reference, live URL and notes, because a batch of
 * designs is a batch of unrelated pages — the About page's screenshots say
 * nothing about the Contact page's Figma frame. Each check is labelled with
 * the page's position whenever there is more than one, so a failure names the
 * design it is about instead of leaving someone to guess which of six.
 */
function preparePage(input, { mode, projectId }, index, total) {
  const page = validate.validatePageName(input.pageName);

  // Screenshot tokens are resolved to staged paths here — the validator is
  // handed absolute paths and never learns that uploads exist. A typed
  // `screenshotPath` still works for a scripted post, the same way
  // `wxrPath` does.
  const isShot = input.referenceType === 'screenshot';
  const shots = isShot
    ? resolveScreenshotTokens(
        input.screenshotTokens,
        // Nothing uploaded this time? A previous run for this same page may
        // have already adopted a set into the page notes, and re-running a page
        // whose build failed should not require finding the files again.
        input.screenshotPath || adoptedReferenceDir({ mode, projectId, pageName: input.pageName }),
      )
    : { files: [], error: null };

  // Tokens sent with some other reference type are staged files nothing will
  // ever adopt, so release them now rather than leaving them for the sweep.
  if (!isShot) releaseUploadTokens(input.screenshotTokens);

  const ref = shots.error
    ? { ok: false, c: check('ref', 'Reference', 'fail', shots.error) }
    : validate.validateReference(input.referenceType, input.figmaLink, input.htmlPath, { screenshots: shots.files });
  const liveUrl = validate.validateLiveUrl(input.liveUrl);
  const notes = validate.validateNotes(input.notes);

  // `ref.value` is an array of paths for a screenshot reference. Everything
  // downstream — the history record, the prompt — wants one string, and the
  // real one is the notes directory the images are copied into. Until that
  // copy happens, their current directory is the honest answer.
  const reference = Array.isArray(ref.value)
    ? (ref.shots && ref.shots.length ? path.dirname(ref.shots[0].path) : '')
    : ref.value;

  // Named as well as numbered: "Page 2" alone is a position in a form someone
  // has already scrolled past by the time they read the check.
  const named = page.ok ? `${index + 1} · ${page.value}` : `${index + 1}`;
  const prefix = total > 1 ? `Page ${named} — ` : '';

  return {
    input,
    prefix,
    ok: page.ok && ref.ok && liveUrl.ok && notes.ok,
    pageName: page.value,
    referenceType: input.referenceType,
    reference,
    ref,
    liveUrl: liveUrl.value,
    notes: notes.value,
    checks: [page.c, ref.c, liveUrl.c, notes.c].filter(Boolean)
      .map((c) => (prefix ? { ...c, label: `${prefix}${c.label}` } : c)),
  };
}

/**
 * Record every page of the batch and adopt its screenshots.
 *
 * Returns what the prompt needs, in the order the pages were given — that is
 * the order they will be built in, so it is not incidental.
 */
function commitPages(prepared, project, checks) {
  // Only a real batch gets an id. One page handed over alone is charged for
  // its whole window, which is what it should be.
  const batchId = prepared.length > 1
    ? `b-${Date.now().toString(36)}-${crypto.randomBytes(4).toString('hex')}`
    : null;

  return prepared.map((p) => {
    const historyEntry = registry.recordPage(project.id, {
      pageName: p.pageName,
      referenceType: p.referenceType,
      reference: p.reference,
      liveUrl: p.liveUrl,
      notes: p.notes,
      batchId,
      status: 'started',
    });

    // After recordPage, which is what creates the notes directory the images
    // are copied into.
    const staged = adoptScreenshots({ prepared: p, project, historyEntry, checks });

    return {
      pageName: p.pageName,
      reference: {
        type: p.referenceType,
        value: staged ? staged.dir : p.reference,
        // Falling back to where the images actually are: saying "no images"
        // over a reference that exists is worse than naming a staged path.
        screenshots: staged ? staged.files : (p.ref.shots || null),
        liveUrl: p.liveUrl,
      },
      notes: p.notes,
      notesDir: historyEntry.notesDir,
      record: historyEntry,
    };
  });
}

function describeContentSource(result, requestedMode) {
  if (result.contentSource === 'db') {
    return check('content', 'WordPress content — extracted automatically', 'pass',
      `${result.contentDetail}. Pages, custom post types, menus, and taxonomies are normalized into the content indexes. No XML export was needed.`);
  }
  if (result.contentSource === 'wxr') {
    return check('content', 'WordPress content — from your export', 'pass',
      `${result.contentDetail}. Parsed once into the same indexes the database path produces; agents never read the XML.`);
  }

  // No content was read this run — but an index from an earlier run may still
  // be in place, and saying "not indexed" when 54 pages are sitting on disk
  // sends the user chasing an export they do not need.
  const cached = result.summary && result.summary.pagesIndexed
    ? `${result.summary.pagesIndexed} pages from ${result.summary.contentSource === 'db' ? 'the local database' : 'a WXR export'}`
    : null;

  if (requestedMode === 'skip') {
    return check('content', 'WordPress content — not re-read', cached ? 'pass' : 'warn',
      cached
        ? `Skipped by request. The existing content index (${cached}) is untouched and still current for this project.`
        : 'Skipped by request, and there is no existing content index. Page discovery will have to work from source code alone, which costs more and is less reliable.');
  }

  return check('content', cached ? 'WordPress content — kept the previous index' : 'WordPress content — not indexed',
    cached ? 'warn' : 'warn',
    cached
      ? `${result.contentDetail || 'no content source was reachable this run'}. The previous index (${cached}) is still in place and was left alone.`
      : `${result.contentDetail || 'no content source'}. The agent will have to find comparable pages from source code alone, which costs more and is less reliable. `
        + 'Export via WordPress Admin > Tools > Export > All content and refresh with the XML.');
}

/** POST /api/refresh — the explicit, opt-in re-scan (spec §19). */
async function refresh(body) {
  const project = registry.get(String(body.projectId || ''));
  if (!project) return { ok: false, checks: [check('project', 'Project', 'fail', 'Select a project to refresh.')] };
  if (!project.pathExists) {
    return {
      ok: false,
      checks: [check('project', 'Project path missing', 'fail',
        `${project.projectPath} no longer exists, so there is nothing to re-scan.`)],
    };
  }

  const contentMode = validate.validateContentMode(body.contentMode || 'auto');
  // Absent means "keep whatever this project already uses"; an explicit null
  // from the UI is how a stored override is cleared back to auto-detection.
  const hasOv = Object.prototype.hasOwnProperty.call(body, 'dbOverride');
  const dbOv = hasOv ? validate.validateDbOverride(body.dbOverride) : { ok: true, value: undefined, c: null };
  if (!dbOv.ok) return { ok: false, checks: [dbOv.c] };

  let wxrPath = null;
  const checks = [];

  let wxrModel = null;
  if (contentMode.value === 'wxr') {
    const staged = body.wxrToken ? resolveStagedUpload(body.wxrToken) : null;
    wxrModel = stagedModel(staged);
    if (wxrModel) {
      wxrPath = staged;
    } else if (staged || body.wxrPath) {
      const wxrCheck = await validate.validateWxrFile(staged || body.wxrPath);
      checks.push(wxrCheck.c);
      if (!wxrCheck.ok) return { ok: false, checks };
      wxrPath = wxrCheck.value;
    }
  }

  const before = intelligence.summary(project.id);
  if (hasOv) registry.update(project.id, { dbOverride: dbOv.value });

  const result = await indexer.indexProject({
    project,
    contentMode: contentMode.value,
    wxrFile: wxrPath,
    wxrRaw: wxrModel,
    preserve: true,   // agent-authored findings and component descriptions survive
    dbOverride: dbOv.value,
  });
  if (dbOv.c) checks.push(dbOv.c);

  if (!result.ok) {
    checks.push(check('refresh', 'Refresh failed', 'fail', result.error));
    return { ok: false, checks };
  }

  if (body.wxrToken) releaseStagedUpload(body.wxrToken);

  checks.push(describeContentSource(result, contentMode.value));
  checks.push(check('refresh', 'Site intelligence refreshed', 'pass',
    `${result.summary.pagesIndexed} pages (was ${before.pagesIndexed || 0}) · `
    + `${result.summary.components} components, ${result.summary.componentsInspected} descriptions preserved · `
    + `${(result.ms / 1000).toFixed(1)}s. Page history and agent-authored findings were kept.`));

  for (const note of result.notes.slice(0, 6)) checks.push(check('note', 'Note', 'warn', note));

  return { ok: true, checks, detail: projectDetail(project.id) };
}

/** POST /api/migrate — import legacy handoff files into per-project directories. */
function runMigration() {
  const result = migrate.run();
  const checks = [];
  if (!result.migrated.length) {
    checks.push(check('migrate', 'Nothing to import', 'pass', 'No un-imported legacy handoff files were found in .claude/tmp/.'));
    return { ok: true, checks, ...result };
  }
  for (const m of result.migrated) {
    checks.push(check('migrate', `Imported into ${m.projectId}`, 'pass',
      `${path.basename(m.from)} → ${path.relative(paths.TMP_ROOT, m.to)}`
      + (m.redacted.length ? ` · redacted: ${m.redacted.join(', ')}` : '')));
  }
  checks.push(check('migrate', 'Originals kept', 'pass',
    'Nothing was deleted or moved. The imported projects are marked as needing a refresh, since a legacy snapshot is not live intelligence.'));
  return { ok: true, checks, ...result };
}

/* ------------------------------------------------------------- WXR upload */

/**
 * Raw-body upload, streamed straight to disk.
 *
 * A WXR can be tens of megabytes; buffering one in memory as base64 inside a
 * JSON post would cost several times its size. The browser sends the File
 * object as the request body and the filename in a header.
 */
const MAX_UPLOAD = 256 * 1024 * 1024;

function stageUpload(req, res, url) {
  ensureDirSync(paths.STAGING_DIR);
  const token = `${Date.now().toString(36)}-${crypto.randomBytes(6).toString('hex')}`;
  const declared = String(url.searchParams.get('name') || 'wordpress-export.xml');
  const safeName = slugify(declared.replace(/\.xml$/i, ''), 'export') + '.xml';
  const target = path.join(paths.STAGING_DIR, `${token}-${safeName}`);

  const out = fs.createWriteStream(target);
  let bytes = 0;
  let aborted = false;

  const abandon = () => {
    if (!out.destroyed) out.destroy();
    fs.unlink(target, () => { /* already gone, or never created */ });
  };

  req.on('data', (chunk) => {
    bytes += chunk.length;
    if (bytes > MAX_UPLOAD && !aborted) {
      aborted = true;
      // Unpipe before destroying: `pipe` pauses its source when the
      // destination goes away, which would strand the request unread and the
      // response unflushed.
      req.unpipe(out);
      abandon();
      send(res, 413, 'application/json', JSON.stringify({
        error: `That file is larger than ${Math.round(MAX_UPLOAD / 1024 / 1024)} MB. Export only the content you need, or use a local database instead.`,
      }));
      req.resume();
    }
  });

  // Without these, a browser that goes away mid-upload leaves this write
  // stream open for the life of the process: `pipe` ends the destination on
  // the source's 'end' and on nothing else.
  req.on('aborted', abandon);
  req.on('error', abandon);

  req.pipe(out);

  out.on('error', (err) => {
    if (aborted) return;
    aborted = true;
    abandon();
    send(res, 500, 'application/json', JSON.stringify({ error: `Could not write the upload (${err.code || err.message}).` }));
  });

  out.on('finish', async () => {
    if (aborted) return;

    // Parse here, once, and stage the normalized model next to the upload.
    // Indexing reuses it, so a 40 MB export is never read twice.
    const parsed = await wxr.parseFile(target);
    if (!parsed.ok) {
      try { fs.unlinkSync(target); } catch { /* noop */ }
      return json(res, 200, {
        ok: false,
        check: check('wxr', 'WXR export', 'fail', parsed.error),
      });
    }

    const byType = Object.entries(parsed.stats.byType).map(([t, n]) => `${n} ${t}`).join(', ') || 'no content items';
    try {
      fs.writeFileSync(`${target}.model.json`, JSON.stringify({ stats: parsed.stats, raw: parsed.raw }), 'utf8');
    } catch {
      // Staging the model is an optimisation; indexing can re-parse if it fails.
    }

    json(res, 200, {
      ok: true,
      token,
      name: declared,
      bytes,
      stats: parsed.stats,
      check: check('wxr', 'WXR export parsed', parsed.stats.posts ? 'pass' : 'warn',
        `WXR ${parsed.stats.wxrVersion}, ${Math.round(bytes / 1024)} KB, ${parsed.stats.items} items — ${byType}. `
        + 'Parsed once, here in the launcher; agents read the indexes, never the XML.'),
    });
  });
}

/**
 * The reference directory a previous run adopted for this page, if it still
 * holds images. Only meaningful for an already-registered project, where the
 * id is known before anything is validated.
 */
function adoptedReferenceDir({ mode, projectId, pageName: rawName }) {
  const id = String(projectId || '');
  const pageName = String(rawName || '').trim();
  if (mode !== 'existing' || !paths.isSafeId(id) || !pageName) return '';

  const dir = path.join(paths.projectPaths(id).pages_, slugify(pageName, 'page'), 'reference');
  try {
    return fs.readdirSync(dir).some((n) => image.IMAGE_EXT_RE.test(n)) ? dir : '';
  } catch {
    return '';
  }
}

/**
 * Turn the browser's upload tokens into absolute staged paths.
 *
 * A token that no longer resolves is dropped rather than faked: the validator
 * then reports "upload at least one screenshot" instead of the launcher
 * silently building a page against half a reference. `typedPath` is the
 * scripted alternative — an absolute image, or a folder of them.
 */
function resolveScreenshotTokens(tokens, typedPath) {
  const fromTokens = (Array.isArray(tokens) ? tokens : tokens ? [tokens] : [])
    .map((t) => resolveStagedUpload(t))
    .filter(Boolean)
    // The staged name carries the upload token; the user chose the rest of it,
    // and that is the half worth showing them in a check.
    .map((p) => ({ path: p, name: path.basename(p).replace(STAGED_PREFIX_RE, '') }));
  if (fromTokens.length) return { files: fromTokens, error: null };

  const typed = String(typedPath || '').trim();
  if (!typed) return { files: [], error: null };

  const st = statOr(typed, null);
  if (st && st.isDirectory()) {
    // Stat succeeding does not mean the directory can be listed — an
    // unreadable one would otherwise throw out of here and become a 500 with a
    // stack trace instead of a check the user can act on.
    let names;
    try {
      names = fs.readdirSync(typed);
    } catch (err) {
      return { files: [], error: `Could not read ${typed} (${err.code || err.message}).` };
    }
    return {
      files: names
        .filter((n) => image.IMAGE_EXT_RE.test(n))
        .sort()
        .map((n) => ({ path: path.join(typed, n), name: n })),
      error: null,
    };
  }
  return { files: [{ path: typed, name: path.basename(typed) }], error: null };
}

/**
 * Move a validated screenshot set into the page's notes directory and release
 * the staging copies. Returns null for every other reference type, so every
 * page of the batch can call it unconditionally.
 */
function adoptScreenshots({ prepared, project, historyEntry, checks }) {
  const { ref, prefix } = prepared;
  if (prepared.referenceType !== 'screenshot' || !ref.shots || !ref.shots.length) return null;

  let staged;
  try {
    staged = materializeScreenshots({
      projectId: project.id,
      pageSlug: historyEntry.slug,
      shots: ref.shots,
    });
  } catch (err) {
    // The images are still readable where they are, so this is a warning and
    // not a failed run: the prompt falls back to the staged paths.
    checks.push(check('ref', `${prefix}Screenshots kept in staging`, 'warn',
      `Could not copy the screenshots into the page notes directory (${err.code || err.message}). `
      + 'The prompt points at the staged copies instead, which are swept after a day — start the build today.'));
    return null;
  }

  // Now that they are copied, the staged originals are duplicates.
  releaseUploadTokens(prepared.input.screenshotTokens);

  registry.advanceStatus(project.id, historyEntry.slug, historyEntry.status, { reference: staged.dir });

  const reused = staged.files.every((s) => path.resolve(path.dirname(s.path)) === path.resolve(staged.dir)
    && ref.shots.some((o) => path.resolve(path.dirname(o.path)) === path.resolve(staged.dir)));
  checks.push(check('ref', `${prefix}${reused ? 'Screenshots reused from the page notes' : 'Screenshots staged for the build'}`, 'pass',
    `${staged.files.length} image${staged.files.length > 1 ? 's' : ''} ${reused ? 'already in' : 'copied to'} ${staged.dir} — `
    + `${staged.files.map((s) => s.name).join(', ')}. `
    + (reused
      ? 'Nothing was uploaded this run; the set adopted for this page earlier is still there and was used as-is.'
      : 'They stay there with the page notes, so re-running this page for the same project reuses them without a re-upload.')));

  return staged;
}

/** The token prefix `stageUpload` puts on a staged filename, for stripping
 *  it back off when the file is copied somewhere a person will read it. */
const STAGED_PREFIX_RE = /^[a-z0-9]+-[a-f0-9]{12}-/i;

/** The `01-desktop-` ordering prefix `materializeScreenshots` adds, so
 *  re-adopting an already-adopted set does not stack a second one on top. */
const ORDER_PREFIX_RE = /^\d{2}-(?:desktop|tablet|mobile|shot)-/i;

/** Resolve an upload token back to its staged file. Never trusts a path. */
function resolveStagedUpload(token) {
  if (!/^[a-z0-9]+-[a-f0-9]{12}$/i.test(String(token))) return null;
  const match = fs.existsSync(paths.STAGING_DIR)
    ? fs.readdirSync(paths.STAGING_DIR).find((f) => f.startsWith(`${token}-`) && !f.endsWith('.model.json'))
    : null;
  return match ? path.join(paths.STAGING_DIR, match) : null;
}

/** The model parsed at upload time, if it is still staged. */
function stagedModel(file) {
  return file ? readJsonSafe(`${file}.model.json`, null) : null;
}

/** Release every staged upload a token list names, in whatever shape it
 *  arrived — a page may carry one token, many, or none at all. */
function releaseUploadTokens(tokens) {
  for (const t of (Array.isArray(tokens) ? tokens : tokens ? [tokens] : [])) releaseStagedUpload(t);
}

/** Delete a staged upload and its parsed model, once it has been imported. */
function releaseStagedUpload(token) {
  const file = resolveStagedUpload(token);
  if (!file) return;
  for (const f of [file, `${file}.model.json`]) {
    try { fs.unlinkSync(f); } catch { /* already gone */ }
  }
}

/* ------------------------------------------------- screenshot upload */

/**
 * A screenshot is not a WXR: it is small, there are several of them per page,
 * and nothing about it needs parsing into a model. So it gets its own limit
 * and its own identification step, and is never handed to the WXR parser.
 */
const MAX_SCREENSHOT = 32 * 1024 * 1024;

/**
 * POST /api/screenshot-upload?name=… — one image, streamed to staging.
 *
 * Identification happens here rather than at Start Building, so a PDF or a
 * renamed HTML page is rejected while the user is still looking at the file
 * picker, not eight checks later.
 */
function stageScreenshot(req, res, url) {
  ensureDirSync(paths.STAGING_DIR);
  const token = `${Date.now().toString(36)}-${crypto.randomBytes(6).toString('hex')}`;
  const declared = String(url.searchParams.get('name') || 'screenshot.png');
  const stem = slugify(declared.replace(image.IMAGE_EXT_RE, ''), 'screenshot');
  // The extension is provisional: the real one comes from the bytes below, and
  // the file is renamed if the two disagree.
  const provisional = (declared.match(image.IMAGE_EXT_RE) || ['.png'])[0].toLowerCase();
  let target = path.join(paths.STAGING_DIR, `${token}-${stem}${provisional}`);

  const out = fs.createWriteStream(target);
  let bytes = 0;
  let aborted = false;

  /** Close the stream and remove the partial file. Safe to call twice. */
  const abandon = () => {
    if (!out.destroyed) out.destroy();
    fs.unlink(target, () => { /* already gone, or never created */ });
  };

  /**
   * Stop writing, answer, and swallow the rest of the body.
   *
   * The unpipe has to come first: destroying a piped destination makes `pipe`
   * tear itself down and *pause* the source, which would undo a `resume` issued
   * before it and leave the request hanging with the response unflushed.
   * Draining rather than destroying the socket is what makes the message
   * reliably reach the browser instead of an ECONNRESET.
   */
  const rejectBody = (status, message) => {
    if (aborted) return;
    aborted = true;
    req.unpipe(out);
    abandon();
    send(res, status, 'application/json', JSON.stringify({ error: message }));
    req.resume();
  };

  req.on('data', (chunk) => {
    bytes += chunk.length;
    if (bytes > MAX_SCREENSHOT && !aborted) {
      rejectBody(413, `${declared} is larger than ${Math.round(MAX_SCREENSHOT / 1024 / 1024)} MB. Export the capture as PNG or JPG at a sane scale rather than a lossless full-page render.`);
    }
  });

  // `pipe` ends the destination on the source's 'end' and on nothing else, so
  // a browser that goes away mid-upload — a reload, a cancelled fetch — would
  // otherwise leave this write stream open for the life of the process.
  req.on('aborted', abandon);
  req.on('error', abandon);

  req.pipe(out);

  out.on('error', (err) => {
    if (aborted) return;
    aborted = true;
    abandon();
    send(res, 500, 'application/json', JSON.stringify({ error: `Could not write the upload (${err.code || err.message}).` }));
  });

  out.on('finish', () => {
    if (aborted) return;

    const info = image.identifyFile(target);
    if (!info.ok) {
      try { fs.unlinkSync(target); } catch { /* noop */ }
      return json(res, 200, {
        ok: false,
        check: check('ref', 'Screenshot', 'fail', `${declared}: ${info.error}`),
      });
    }

    // A real image, but one no agent can open — an iPhone screenshot dragged
    // straight off a Mac is HEIC. Better said now, at the file picker, than
    // after the build has been handed off.
    const unreadable = image.unreadableReason(info.format);
    if (unreadable) {
      try { fs.unlinkSync(target); } catch { /* noop */ }
      return json(res, 200, {
        ok: false,
        check: check('ref', 'Screenshot', 'fail', `${declared}: ${unreadable}`),
      });
    }

    // Trust the bytes over the filename — a `.png` that is really a JPEG would
    // otherwise be copied into the page notes under a lying extension.
    if (`.${info.ext}` !== provisional) {
      const renamed = path.join(paths.STAGING_DIR, `${token}-${stem}.${info.ext}`);
      try { fs.renameSync(target, renamed); target = renamed; } catch { /* keep the original name */ }
    }

    json(res, 200, {
      ok: true,
      token,
      name: declared,
      bytes,
      format: info.format,
      width: info.width,
      height: info.height,
      size: image.describeSize(info),
      viewport: image.guessViewport(info),
    });
  });
}

/**
 * Copy the staged screenshots into the page's own notes directory.
 *
 * The staging area is swept after a day, and a prompt someone pastes next week
 * would point at files that no longer exist. Under `pages/<slug>/reference/`
 * they live beside the reference section list and the reuse decision table
 * that describe them, and a re-run of the same page finds them still there.
 */
function materializeScreenshots({ projectId, pageSlug, shots }) {
  const dir = path.join(paths.projectPaths(projectId).pages_, pageSlug, 'reference');
  ensureDirSync(dir);

  // A scripted `screenshotPath` may legitimately point at this very directory —
  // re-running a page against the set already adopted for it. Sweeping first
  // would then delete the files about to be copied, so the sources are named
  // before anything is removed.
  const sources = new Set(shots.map((s) => path.resolve(s.path)));

  const planned = shots.map((shot, i) => {
    const n = String(i + 1).padStart(2, '0');
    const label = shot.viewport || 'shot';
    // The staging token is plumbing, and so is an ordering prefix this function
    // added on an earlier run; `01-desktop-hero.png` is what belongs in a
    // directory a person and an agent both read.
    const stem = path.basename(shot.name)
      .replace(STAGED_PREFIX_RE, '')
      .replace(ORDER_PREFIX_RE, '')
      .replace(image.IMAGE_EXT_RE, '');
    const name = `${n}-${label}-${slugify(stem, 'screenshot')}.${shot.ext}`;
    return { shot, name, dest: path.join(dir, name) };
  });

  // A re-run replaces the reference set rather than accumulating one, so the
  // directory never ends up holding two different designs for one page.
  const keep = new Set([...sources, ...planned.map((p) => path.resolve(p.dest))]);
  for (const stale of fs.readdirSync(dir)) {
    const full = path.join(dir, stale);
    if (image.IMAGE_EXT_RE.test(stale) && !keep.has(path.resolve(full))) {
      try { fs.unlinkSync(full); } catch { /* noop */ }
    }
  }

  const files = [];
  for (const { shot, name, dest } of planned) {
    if (path.resolve(shot.path) !== path.resolve(dest)) fs.copyFileSync(shot.path, dest);
    files.push({ ...shot, path: dest, name });
  }

  // Any source that lived here under a different name has now been copied to
  // its planned one, so the original is a duplicate.
  const written = new Set(files.map((f) => path.resolve(f.path)));
  for (const src of sources) {
    if (!written.has(src) && path.resolve(path.dirname(src)) === path.resolve(dir)) {
      try { fs.unlinkSync(src); } catch { /* noop */ }
    }
  }

  return { dir, files };
}

/** Staged uploads older than a day are abandoned attempts. Run at startup and
 *  then periodically, since a launcher is routinely left open for days. */
function sweepStaging() {
  if (!fs.existsSync(paths.STAGING_DIR)) return;
  const cutoff = Date.now() - 24 * 60 * 60 * 1000;
  for (const f of fs.readdirSync(paths.STAGING_DIR)) {
    const full = path.join(paths.STAGING_DIR, f);
    const st = statOr(full);
    if (st && st.mtimeMs < cutoff) {
      try { fs.unlinkSync(full); } catch { /* noop */ }
    }
  }
}

/* ----------------------------------------------------------------- server */

function fmtDate(iso) {
  if (!iso) return 'never';
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? String(iso) : d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
}

function send(res, status, type, body) {
  if (res.headersSent) return;
  res.writeHead(status, {
    'Content-Type': type,
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  });
  res.end(body);
}

const json = (res, status, value) => send(res, status, 'application/json', JSON.stringify(value));

/** Reject cross-origin posts; this server touches the local filesystem. */
/**
 * Is the Host header one of ours?
 *
 * The server binds 127.0.0.1, so Host is always loopback in normal use.
 * Checking it closes DNS rebinding: a page on any domain whose DNS is made to
 * resolve to 127.0.0.1 looks same-origin to the browser, so no Origin header
 * is sent on its GETs and no CORS check applies — and the project paths,
 * theme names and page lists behind these endpoints would be readable.
 */
function hostAllowed(req) {
  const raw = String(req.headers.host || '');
  if (!raw) return true;                       // HTTP/1.0 clients send none
  const name = raw.replace(/:\d+$/, '').replace(/^\[|\]$/g, '').toLowerCase();
  return name === '127.0.0.1' || name === 'localhost' || name === '::1';
}

function originAllowed(req) {
  const origin = req.headers.origin;
  if (!origin) return true; // same-origin fetches from the served page send none
  try {
    const { hostname } = new URL(origin);
    return hostname === '127.0.0.1' || hostname === 'localhost';
  } catch {
    return false;
  }
}

function readBody(req, limit = 2 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', (c) => {
      raw += c;
      if (raw.length > limit) {
        req.destroy();
        reject(new Error('Request body too large.'));
      }
    });
    req.on('end', () => resolve(raw));
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${HOST}:${PORT}`);
  const route = url.pathname;

  // Before anything else, including the static page: a request addressed to
  // someone else's hostname is not for us, whatever it asks for.
  if (!hostAllowed(req)) {
    return send(res, 403, 'text/plain', 'This launcher only answers requests addressed to 127.0.0.1 or localhost.');
  }

  try {
    if (req.method === 'GET' && (route === '/' || route === '/index.html')) {
      try {
        const html = await fsp.readFile(path.join(__dirname, 'public', 'index.html'));
        return send(res, 200, 'text/html; charset=utf-8', html);
      } catch {
        return send(res, 500, 'text/plain', 'Could not read launcher/public/index.html');
      }
    }

    if (req.method === 'GET' && route === '/api/health') {
      // `build` is how the starter tells "already running" apart from
      // "running, but from before the last edit".
      return json(res, 200, { app: APP_ID, version: APP_VERSION, pid: process.pid, build: BUILD_ID });
    }

    if (req.method === 'GET' && route === '/api/projects') {
      return json(res, 200, listProjects());
    }

    if (req.method === 'GET' && route.startsWith('/api/progress/')) {
      const id = decodeURIComponent(route.slice('/api/progress/'.length));
      if (!paths.isSafeId(id)) return json(res, 400, { error: 'Unusable project id.' });
      const result = pageProgress(id);
      return json(res, result.error ? 404 : 200, result);
    }

    if (req.method === 'GET' && route.startsWith('/api/projects/')) {
      const id = decodeURIComponent(route.slice('/api/projects/'.length));
      if (!paths.isSafeId(id)) return json(res, 400, { error: 'Unusable project id.' });
      return json(res, 200, projectDetail(id));
    }

    if (req.method === 'GET' && route === '/api/legacy') {
      return json(res, 200, { items: migrate.inspect() });
    }

    if (req.method === 'POST') {
      if (!originAllowed(req)) return json(res, 403, { error: 'Cross-origin request refused.' });

      if (route === '/api/wxr-upload') {
        return stageUpload(req, res, url);
      }

      if (route === '/api/screenshot-upload') {
        return stageScreenshot(req, res, url);
      }

      if (route === '/api/screenshot-discard') {
        // Removing a row in the browser should not leave its upload sitting in
        // staging until the next sweep.
        releaseStagedUpload(url.searchParams.get('token'));
        return json(res, 200, { ok: true });
      }

      const raw = await readBody(req);
      let body;
      try {
        body = JSON.parse(raw || '{}');
      } catch (err) {
        return json(res, 400, { error: `Could not parse the request body: ${err.message}` });
      }

      if (route === '/api/inspect') return json(res, 200, await inspect(body));
      if (route === '/api/validate') return json(res, 200, await handleStart(body));
      if (route === '/api/db-detect') return json(res, 200, await dbDetect(body));
      if (route === '/api/refresh') return json(res, 200, await refresh(body));
      if (route === '/api/migrate') return json(res, 200, runMigration());
    }

    return send(res, 404, 'text/plain', 'Not found');
  } catch (err) {
    // A thrown error here would otherwise take the whole launcher down and
    // look, from the browser, exactly like the server having been stopped.
    console.error(`[${nowIso()}] ${req.method} ${route} failed:`, err && err.stack || err);
    return json(res, 500, { error: String((err && err.message) || err) });
  }
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`\n  Port ${PORT} is already in use.\n  Try:  PORT=4600 node launcher/server.js\n`);
    process.exit(1);
  }
  throw err;
});

server.listen(PORT, HOST, () => {
  paths.ensureTmpRoot();
  sweepStaging();
  // A launcher is routinely left running for days, so a startup-only sweep
  // never reclaims anything abandoned during the session. `unref` so the timer
  // does not by itself hold the process open.
  setInterval(sweepStaging, 6 * 60 * 60 * 1000).unref();
  const { projects, repaired, problems } = registry.load();
  if (repaired) registry.save(projects, problems);
  const legacy = migrate.inspect().filter((l) => !l.alreadyImported).length;

  console.log(`\n  Page Builder launcher running at http://${HOST}:${PORT}`);
  console.log(`  Projects: ${projects.length}${legacy ? ` · ${legacy} legacy handoff file(s) available to import` : ''}`);
  if (problems.length) console.log(`  Registry repaired: ${problems.length} issue(s)`);

  // Repairs the absolute paths in .claude/settings.json when this folder has
  // moved or been cloned, and reports anything else that needs a human. Prints
  // nothing at all on a correct install.
  for (const line of preflight.run()) console.log(line);

  console.log('  Local only — nothing is uploaded. Ctrl+C to stop.\n');
});

/**
 * The starter sends SIGTERM when it replaces an out-of-date server. Closing
 * the listener first lets an in-flight request finish instead of the browser
 * seeing a dropped connection; the timer is the backstop for a keep-alive
 * socket that would otherwise hold the port and stall the replacement.
 *
 * On Windows this handler mostly will not run: `process.kill` from another
 * process terminates forcefully there, signals being a POSIX idea. That is
 * fine — the port is released immediately either way, and the starter waits
 * for exactly that rather than for a clean exit.
 */
for (const sig of ['SIGTERM', 'SIGINT']) {
  process.on(sig, () => {
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 2000).unref();
  });
}
