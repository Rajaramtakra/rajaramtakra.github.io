# Page Builder — working in this repo

A Claude Code agent pipeline that builds new pages inside an **existing local
WordPress project** from a Figma, HTML or screenshot reference. This repo is
the *tool*; the WordPress sites it operates on live elsewhere on the machine
(typically under MAMP) and are never part of this tree.

**Primary rule of the product:** the existing WordPress project is the source
of truth for *how* a page is implemented; the reference is the source of truth
for *what it looks like*. Reuse the site's architecture, don't introduce a new
one.

---

## Never read these

- **`.claude/tmp/**/site-intelligence/source/wordpress-export.xml`** — a real
  WXR export runs to ~36 MB, about **10.5M tokens**. The launcher parses it
  once into indexes that are ~334× smaller. Read the indexes, never the XML.
- **`.claude/tmp/**/push/*.sql`, `*.tar.gz`, `*.zip`** — client database dumps
  and upload archives.
- Screenshots under `.claude/tmp/**/shots/` in bulk — they are large, and there
  are hundreds.

## `.claude/tmp/` is cache, not source

One directory per WordPress project the tool has been pointed at: site
intelligence, reference images, QA screenshots, per-page notes. It is
**gitignored and must stay that way** — it holds real client site content, and
the launcher rebuilds all of it on demand. Only `.gitkeep` is tracked.

If you need something from it, prefer the query tool over reading files:

```bash
node tools/query-index.js pages --project <id>          # every page, compressed
node tools/query-index.js components --project <id>
node tools/verify-page.js --project <id> --page <slug>  # deterministic checks
```

`query-index.js --limit` hides rows; never pass it when making a decision.

---

## Layout

| Path | What it is |
| :-- | :-- |
| `launcher/` | Node UI + all deterministic work: WP detection, DB/WXR indexing, prompt generation |
| `launcher/lib/` | One module per concern; `paths.js` owns the workspace layout |
| `tools/` | The two scripts the agents call: `query-index.js`, `verify-page.js` |
| `.claude/agents/` | The four agent definitions — **each file's body is that agent's prompt** |
| `docs/walkthrough/` | Eight-step HTML walk-through, no server needed |
| `configuration.md` | What the harness loads, from where, and what is deliberately not configured |

## Conventions

- **Zero dependencies.** No `npm install`, no native modules, no build step.
  Keep it that way — dependency-free Node that behaves identically on macOS,
  Windows and Linux is a deliberate constraint, not an accident.
- **Node >= 18** (`launcher/package.json`). The startup preflight warns below
  that rather than failing.
- Use the `node:` prefix on core imports, matching the existing code.
- Comments here explain **why**, not what. Match that — the existing code is
  dense with rationale for decisions that look arbitrary without it.
- There is **no test suite**. Verify changes by running the thing (below).

## Running it

```bash
node launcher/start.js          # finds a free port, opens a browser (default 4599)
node launcher/server.js         # server only; PORT=8791 to override
```

Startup runs `launcher/lib/preflight.js`, which **rewrites the absolute paths
in `.claude/settings.json` to match wherever this folder now lives** and warns
about a stale `~/.claude/agents/` copy or an old Node. It prints nothing on a
healthy install — silence is the pass condition.

## Editing agents

`.claude/agents/*.md` bodies are prompts, not documentation. Consolidating or
summarising them deletes agent behaviour. If the four files are also copied to
`~/.claude/agents/`, Claude Code prefers that copy — re-copy after editing, or
the preflight will tell you they have drifted.
