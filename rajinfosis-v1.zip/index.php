<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="images/favicon.ico" type="images/x-icon" />
    <title>Rajinfosis</title>
    <!-- <link type="text/css" rel="stylesheet" href="lib/animate.min.css" /> -->
    <link type="text/css" rel="stylesheet" href="lib/slick/slick.css" />
    <link type="text/css" rel="stylesheet" href="lib/animate.min.css" />
    <link type="text/css" rel="stylesheet" href="lib/font-awesome/css/font-awesome.min.css" />
    <link type="text/css" rel="stylesheet" href="lib/bootstrap/css/bootstrap.min.css" />
    <link type="text/css" rel="stylesheet" href="css/main.css" />
</head>

<body>
    <div id="wrapper">
        <?php include('inc/header.php') ?>
        <!--Header-->
        <main id="main">
            <section class="home-banner">
                <div class="video-container">
                    <div class="filter"></div>
                    <video autoplay loop class="fillWidth">
                        <source src="images/media/bannervideo.mp4" type="video/mp4"/>
                    </video>
                </div>
                <div class="caption">
                    <div class="caption-wrap">
                        <h1 class="typewrite" data-period="2000" data-type="[ &quot;Welcome to Rajinfosis learn a new skill.&quot;, &quot;BUILDING GLOBAL IT PROFESSIONALS SINCE 2008.&quot;, &quot;Be a certified digital marketer.&quot;, &quot;World Class Digital Marketing.&quot; ]">
                            <span class="wrap">Experience Adventure </span>
                        </h1>
                        <a href="#" class="btn btn-secondary" data-toggle="modal" data-target="#quoteModal">Send Enquiry</a>
                    </div>
                </div>
            </section>
            <!--/.header_banner-->

            <section class="intro-block top-btm-gutter5 text-center text-md-left">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-md-6 col-lg-5 text-md-right intro-block-title">
                            <h3><i class="fa fa-graduation-cap"></i> Welcome to <br>Raj <span>Infosys</span> Nepal </h3>
                            <h5 class="slogan">A COMPREHENSIVE IT TRAINING CENTER IN NEPAL</h5>
                        </div>
                        <div class="col-md-6 col-lg-7 intro-block-content">
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                            <a class="btn btn-secondary" href="#"> Read More</a>
                        </div>
                    </div>
                </div>
            </section> <!--/.intro-block-->

            <!-- COURSES BLOCK -->
            <section class="category-block block-section text-center top-btm-gutter8"
                style="background-image: url('images/courses-bg.png')" data-stellar-background-ratio="0.5">
                <div class="container overlay-content">
                    <div class="headline-block">
                        <h2 class="title-style2">Professional IT Courses In Australia</h2>

                    </div>
                    <div class="row justify-content-center">
                        <div class="col-md-3 col-sm-6 col-xs-6">
                            <a href="digitalmarketing.html" class="courses-block equal">
                                <div class="img-wrap">
                                    <img src="images/course/pJnkRR_1525123953-digitalmarketing.png" alt="digitalmarketing">
                                </div>
                                <span>Digital Marketing</span>
                                <div class="desc">
                                    <div class="valign-middle">
                                        <p> Learn how to harness the Internet to promote your business, product or
                                            services
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6">
                            <a href="course/ios-app-development.html" class="courses-block equal">
                                <div class="img-wrap">
                                    <img src="images/course/yU7wXY_1502688778-oNwUZM_1496391982-icon-apple.png" alt="icon-apple">
                                </div>
                                <span>iOS App Development</span>
                                <div class="desc">
                                    <div class="valign-middle">
                                        <p> By completing this course, you will learn how to make great iOS apps.
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6">
                            <a href="course/front-end-development.html" class="courses-block equal">
                                <div class="img-wrap">
                                    <img src="images/course/VGvR0z_1502688803-BvJ8FI_1496655168-icon-web-design.png" alt="icon-web-design">
                                </div>
                                <span>Front End Development</span>
                                <div class="desc">
                                    <div class="valign-middle">
                                        <p> If you want to develop beautiful front-end pages, this is the course for
                                            you.
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6">
                            <a href="course/graphic-designing.html" class="courses-block equal">
                                <div class="img-wrap">
                                    <img src="images/course/I0xmpi_1502688841-Vx4Eg3_1496660436-icon-graphic-design.png" alt="icon-graphic-design">
                                </div>
                                <span>Graphic Designing</span>
                                <div class="desc">
                                    <div class="valign-middle">
                                        <p> This course is for you if you want to get your message out using texts and
                                            pictures.
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6">
                            <a href="course/animation-2d.html" class="courses-block equal">
                                <div class="img-wrap">
                                    <img src="images/course/f6f7DE_1502688918-zgBKUS_1496989411-animation.png" alt="animation">
                                </div>
                                <span>Animation - 2D</span>
                                <div class="desc">
                                    <div class="valign-middle">
                                        <p> This course teaches you how to bring 2D images to life.
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6">
                            <a href="course/linux.html" class="courses-block equal">
                                <div class="img-wrap">
                                    <img src="images/course/0lli7Z_1502689170-39g0tz_1496991621-icon-linux.png" alt="icon-linux">
                                </div>
                                <span>Linux</span>
                                <div class="desc">
                                    <div class="valign-middle">
                                        <p> Let us decode the mystery surrounding Linux Operating System.
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6">
                            <a href="course/laravel-web-development.html" class="courses-block equal">
                                <div class="img-wrap">
                                    <img src="images/course/rEhAuV_1525123976-laravel.png" alt="laravel">
                                </div>
                                <span>Laravel Web Development</span>
                                <div class="desc">
                                    <div class="valign-middle">
                                        <p> With Laravel, you can develop advanced web sites and web applications.
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6">
                            <a href="digitalmarketing.html" class="courses-block equal">
                                <div class="img-wrap">
                                    <img src="images/course/YLPpop_1502689217-QQikov_1498984987-seo.png" alt="seo">
                                </div>
                                <span>SEO</span>
                                <div class="desc">
                                    <div class="valign-middle">
                                        <p> Learn how to rank higher organically.
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6">
                            <a href="course/android-app-development.html" class="courses-block equal">
                                <div class="img-wrap">
                                    <img src="images/course/eNakoI_1502689296-Ip8o3j_1498986758-android.png" alt="android">
                                </div>
                                <span>Android App Development</span>
                                <div class="desc">
                                    <div class="valign-middle">
                                        <p> Build exciting application for your Android phone
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6">
                            <a href="course/asp.html" class="courses-block equal">
                                <div class="img-wrap">
                                    <img src="images/course/MeAFuS_1502689315-Kuhh4a_1498988369-asp.png" alt="asp">
                                </div>
                                <span>ASP.NET</span>
                                <div class="desc">
                                    <div class="valign-middle">
                                        <p> Learn ASP.NET to build secure websites and web applications.
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6">
                            <a href="course/basic-java.html" class="courses-block equal">
                                <div class="img-wrap">
                                    <img src="images/course/u9m7k8_1502689332-JZu56t_1498990712-java.png" alt="java">
                                </div>
                                <span>Basic Java</span>
                                <div class="desc">
                                    <div class="valign-middle">
                                        <p> Learn Java to code programs that can run on any operating system.
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6">
                            <a href="course/c-c-plus-plus-training.html" class="courses-block equal">
                                <div class="img-wrap">
                                    <img src="images/course/EwbaD6_1502689368-aQNumv_1498992479-c.png" alt="c">
                                </div>
                                <span>C/C++</span>
                                <div class="desc">
                                    <div class="valign-middle">
                                        <p> Get familiar with programming by learning C &amp; C++.
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6">
                            <a href="course/csharp-net.html" class="courses-block equal">
                                <div class="img-wrap">
                                    <img src="images/course/VrRCAr_1502689384-0gqaeu_1498993781-Cnet.png" alt="Cnet">
                                </div>
                                <span>C#.NET</span>
                                <div class="desc">
                                    <div class="valign-middle">
                                        <p> Learn to write programs on .NET framework.
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6">
                            <a href="course/drupal.html" class="courses-block equal">
                                <div class="img-wrap">
                                    <img src="images/course/Vn4nUF_1502689422-DsRJOs_1498994139-drupal.png" alt="drupal">
                                </div>
                                <span>Drupal</span>
                                <div class="desc">
                                    <div class="valign-middle">
                                        <p> Drupal allows you to create, develop and manage your content online.
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6">
                            <a href="course/magento.html" class="courses-block equal">
                                <div class="img-wrap">
                                    <img src="images/course/ddWEGf_1502689444-jAjm2K_1498994505-magento.png" alt="magento">
                                </div>
                                <span>Magento</span>
                                <div class="desc">
                                    <div class="valign-middle">
                                        <p> Magento is an open source CMS created for developing eCommerce websites.
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6">
                            <a href="course/wordpress.html" class="courses-block equal">
                                <div class="img-wrap">
                                    <img src="images/course/bgjVUV_1498994858-wordpress.png" alt="wordpress">
                                </div>
                                <span>WordPress</span>
                                <div class="desc">
                                    <div class="valign-middle">
                                        <p> Learn WordPress to create, develop and manage your content.
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6">
                            <a href="course/joomla.html" class="courses-block equal">
                                <div class="img-wrap">
                                    <img src="images/course/UJZwJk_1502689506-qNclnH_1499060264-joomla.png" alt="joomla">
                                </div>
                                <span>Joomla</span>
                                <div class="desc">
                                    <div class="valign-middle">
                                        <p> This course on Joomla will teach you to build websites and web applications
                                            fast.
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6">
                            <a href="course/advanced-java-course.html" class="courses-block equal">
                                <div class="img-wrap">
                                    <img src="images/course/fWOeCs_1502689522-JZu56t_1498990712-java.png" alt="java">
                                </div>
                                <span>Advanced Java</span>
                                <div class="desc">
                                    <div class="valign-middle">
                                        <p> Learn Advanced Java to make the most out of it.
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="overlay overlay-blue"></div>
            </section>
            <!-- TESTIMONIALS BLOCK-->
            <section class="testimonial-block top-btm-gutter8 text-center text-sm-left">
                <div class="container">
                    <div class="row">
                        <div class="col-md-5 col-sm-5 col-xs-12">
                            <div class="brand-slider">
                                <div class="slider-item">
                                    <img src="images/Ha04JO_1497005196-best-quality.png"
                                        data-animation-in="flipInY" alt="">
                                </div>

                                <div class="slider-item">
                                    <img src="images/Ffuon1_1497005225-best-instructors.png"
                                        data-animation-in="pulse" alt="">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                            <div class="testimonial-section">
                                <h2 class="title-style2 title-border">Testimonials</h2>
                                <div class="testimonial-slider">
                                    <div class="slider-item">
                                        <blockquote>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                                        </blockquote>
                                        <img src="images/testinomial/ubwqZo_1505108539-bijaya.png" class="client" alt="">
                                        <h5 class="title-style5">Bijaya Kumar Barakoti</h5>
                                        <span class="position title-style">Founder/Creative Director at SunBi Design
                                            Studio</span>
                                    </div>
                                    <div class="slider-item">
                                        <blockquote>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                                        </blockquote>
                                        <img src="images/testinomial/7z5ckT_1503206803-Suyog.jpg" class="client" alt="">
                                        <h5 class="title-style5">Suyog Thakuri</h5>
                                        <span class="position title-style">Graphic Designer at Rillmark</span>
                                    </div>
                                    <div class="slider-item">
                                        <blockquote>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                                        </blockquote>
                                        <img src="images/testinomial/lB1XpA_1503206787-sirjana.jpg" class="client"
                                            alt="">
                                        <h5 class="title-style5">Srijana Maharjan</h5>
                                        <span class="position title-style">Front End Developer at Rillmark</span>
                                    </div>
                                    <div class="slider-item">
                                        <blockquote>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                                        </blockquote>
                                        <img src="images/testinomial/OV7skl_1503206763-Pragya.jpg" class="client" alt="">
                                        <h5 class="title-style5">Pragya Gurung</h5>
                                        <span class="position title-style">Brand Manager at Rillmark</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="section-row">
                <div class="parallax-content bg-parallax bg-howWeAssistance">
                    <div class="parallax-overlay top-btm-gutter8">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-7 mob-hide">
                                    <div class="assist-process">
                                        <div class="block-header">
                                            <h3><span class="first-word"> How </span> we assist you for your
                                                Career?</h3>
                                            <p>We not only offer career-oriented IT training in Nepal as per industry
                                                needs
                                                but also guarantee
                                                successful job placements for deserving students and professionals.</p>
                                        </div>
                                        <div class="block-body">
                                            <div class="row">
                                                <div class="col-xs-12 col-sm-6 col-md-6">
                                                    <div class="process-item">
                                                        <a href="training.html" target="_blank">
                                                            <div class="item-icon">
                                                                <div class="circle-icon">
                                                                    <img src="images/svg-icons/training.svg" alt="training">
                                                                </div>
                                                            </div>
                                                            <div class="item-content">
                                                                <h4>Training</h4>
                                                            </div>
                                                        </a>
                                                    </div>
                                                </div>
                                                <div class="col-xs-12 col-sm-6 col-md-6">
                                                    <div class="process-item">
                                                        <a href="project-work.html" target="_blank">
                                                            <div class="item-icon">
                                                                <div class="circle-icon">
                                                                    <img src="images/svg-icons/project-work.svg" alt="project-work">
                                                                </div>
                                                            </div>
                                                            <div class="item-content">
                                                                <h4>Project Work</h4>
                                                            </div>
                                                        </a>
                                                    </div>
                                                </div>
                                                <div class="col-xs-12 col-sm-6 col-md-6">
                                                    <div class="process-item">
                                                        <a href="evaluation.html" target="_blank">
                                                            <div class="item-icon">
                                                                <div class="circle-icon">
                                                                    <img src="images/svg-icons/evaluation.svg" alt="evaluation">
                                                                </div>
                                                            </div>
                                                            <div class="item-content">
                                                                <h4>Evaluation</h4>
                                                            </div>
                                                        </a>
                                                    </div>
                                                </div>
                                                <div class="col-xs-12 col-sm-6 col-md-6">
                                                    <div class="process-item">
                                                        <a href="internship-placement.html" target="_blank">
                                                            <div class="item-icon">
                                                                <div class="circle-icon">
                                                                    <img src="images/svg-icons/placement.svg" alt="placement">
                                                                </div>
                                                            </div>
                                                            <div class="item-content">
                                                                <h4>Internship/Placement</h4>
                                                            </div>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="quickQuery">
                                        <form method="POST" class="base-form form-vertical">
                                            <div class="form-header">
                                                <h3>Request AN ENQUIRY</h3>
                                            </div>
                                            <div class="form-body">
                                                <div class="form-group">
                                                    <input name="5896nm" type="text" placeholder="Your Name..." required>
                                                </div>
                                                <div class="form-group">
                                                <input name="5896nm" type="text" placeholder="Your Email" required>
                                                </div>
                                                <div class="form-group">
                                                    <input required="" name="Telephone" type="tel" placeholder="Your Phone">
                                                </div>
                                                <div class="form-group">
                                                    <select name="Course" required>
                                                        <option value="PHP">PHP Framework</option>
                                                        <option value="Web">Web Design / Frontend </option>
                                                        <option value="React">React Js</option>
                                                        <option value="Angular">Angular Js</option>
                                                        <option value="Net">.Net</option>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label sr-only">Message <span
                                                            class="required">*</span></label>
                                                    <textarea placeholder="Your Message..." required=""
                                                        name="5896ms" cols="50" rows="6"></textarea>
                                                </div>
                                                <div class="form-group">
                                                    <button type="submit" tabindex="8" id="enquiry-submit-btn"
                                                        class="btn btn-secondary"><i
                                                            class="fa fa-paper-plane-o"></i>
                                                        Send Enquiry
                                                    </button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="parnters top-btm-gutter8">
                <div class="container">
                    <div class="section-title btm-gutter3">
                        <h2>Our Partners</h2>
                    </div>
                    <div class="parnters-slider">
                        <div class="parnters-item">
                            <div class="icon-box">
                                <img src="images/partner/cisco.png" alt="cisco">
                            </div>
                        </div>
                        <div class="parnters-item">
                            <div class="icon-box">
                                <img src="images/partner/dellemc_logo.png" alt="dellemc_logo">
                            </div>
                        </div>
                        <div class="parnters-item">
                            <div class="icon-box">
                                <img src="images/partner/ec-council.png" alt="ec-council">
                            </div>
                        </div>
                        <div class="parnters-item">
                            <div class="icon-box">
                                <img src="images/partner/pearson-vuer.png" alt="pearson-vuer">
                            </div>
                        </div>
                        <div class="parnters-item">
                            <div class="icon-box">
                                <img src="images/partner/simplilearn.png" alt="simplilearn">
                            </div>
                        </div>
                        <div class="parnters-item">
                            <div class="icon-box">
                                <img src="images/partner/vmware.png" alt="vmware">
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!--/.parnters-->

        </main>
        <!--Main-->
        <?php include('inc/footer.php') ?>
        <!--Footer-->
    </div>
</body>

</html>